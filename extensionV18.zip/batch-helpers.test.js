const test = require('node:test');
const assert = require('node:assert/strict');
const { isGAMTabUrl, buildTabQueue, getRetryQueue } = require('./batch-helpers.js');

test('isGAMTabUrl only matches Google Ad Manager hosts', () => {
  assert.equal(isGAMTabUrl('https://admanager.google.com/12345#creative'), true);
  assert.equal(isGAMTabUrl('https://example.com/dashboard'), false);
});

test('buildTabQueue filters to GAM tabs and sets pending status', () => {
  const tabs = [
    { id: 1, title: 'GAM - bola.net creative', url: 'https://admanager.google.com/1#creative' },
    { id: 2, title: 'Unrelated tab', url: 'https://example.com/' },
    { id: 3, title: 'GAM - lagidiskon.id creative', url: 'https://admanager.google.com/2#creative' }
  ];

  const queue = buildTabQueue(tabs);
  assert.equal(queue.length, 2);
  assert.equal(queue[0].tabId, 1);
  assert.equal(queue[0].status, 'pending');
  assert.equal(queue[1].tabId, 3);
});

test('getRetryQueue returns only failed items', () => {
  const queue = [
    { tabId: 1, status: 'success' },
    { tabId: 2, status: 'failed' },
    { tabId: 3, status: 'failed' }
  ];

  const retry = getRetryQueue(queue);
  assert.equal(retry.length, 2);
  assert.deepEqual(retry.map((item) => item.tabId), [2, 3]);
});
