const DEFAULT_DRIVE_SOURCE_URL = 'https://drive.google.com/file/d/1je54X0abTr10oA-0u0jx8Cnpxg8adBLD/view?usp=sharing';

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    lagidiskonConfig: {
      sources: Array.from({ length: 6 }, (_, i) => ({
        id: `source${i + 1}`,
        value: i === 0 ? DEFAULT_DRIVE_SOURCE_URL : ''
      }))
    }
  });
});

// ---------------------------------------------------------------------------
// Bulk save.
//
// This lives here, not in popup.js, on purpose. Clicking Save on a
// background (non-focused) tab silently does nothing in GAM - see
// activateTabForSave() below - so each tab has to be briefly brought to the
// foreground right before its Save click. But focusing another tab/window
// is exactly the kind of event Chrome uses to auto-close an extension's own
// popup, and a closed popup's JS context is torn down immediately,
// mid-await, taking any loop running inside it down with it. That's what
// was causing some tabs to save silently with no log line and no error:
// the popup was gone by the time their turn came up, not stuck.
//
// The background service worker isn't tied to the popup's lifetime, so
// running the activate-then-save loop here means it keeps going (and keeps
// producing a real result for every tab) even if focusing a GAM tab closes
// the popup UI sitting on top of it. Progress still streams live to the
// popup via BULK_SAVE_PROGRESS broadcasts while it stays open; the final
// tally is also written to chrome.storage.local so a reopened popup can
// show what happened while it was closed, instead of looking like nothing
// ran at all.
// ---------------------------------------------------------------------------

async function activateTabForSave(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab?.windowId != null) {
      await chrome.windows.update(tab.windowId, { focused: true });
    }
    await chrome.tabs.update(tabId, { active: true });

    // Give Chrome a moment to actually resume the tab - becoming "active"
    // and having already caught up on paused rAF/digest work aren't the
    // same instant.
    await new Promise((resolve) => setTimeout(resolve, 250));
  } catch {
    // Best-effort - e.g. the tab was closed mid-run. Fall through and let
    // the save attempt itself report the failure.
  }
}

async function clickSaveOnTab(tabId) {
  try {
    const response = await chrome.tabs.sendMessage(tabId, { type: 'CLICK_SAVE_AND_PREVIEW' });
    if (response) return response;
  } catch {
    // fall through to the injection fallback below - same two-step
    // strategy as popup.js's invokeGAMTabAction, kept separate here since
    // it only ever needs to run this one action.
  }

  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['gam-helpers.js'] });
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const helpers = window.GAM_HELPERS;
        return helpers && typeof helpers.clickSaveAndPreview === 'function'
          ? helpers.clickSaveAndPreview(document)
          : { ok: false, reason: 'Save helper is not available.' };
      }
    });
    return results?.[0]?.result || { ok: false, reason: 'No result returned from the page fallback.' };
  } catch (error) {
    return { ok: false, reason: `Could not reach the tab to save: ${error.message}` };
  }
}

function broadcastBulkSaveProgress(result) {
  try {
    // No listener (e.g. the popup already closed) just means this rejects -
    // the final summary in chrome.storage.local below covers that case, so
    // there's nothing to recover from here.
    chrome.runtime.sendMessage({ type: 'BULK_SAVE_PROGRESS', result })?.catch?.(() => {});
  } catch {
    // Some Chrome versions throw synchronously instead of rejecting.
  }
}

async function runBulkSave(items) {
  const originalActiveTab = await chrome.tabs.query({ active: true, currentWindow: true })
    .then((tabs) => tabs[0] || null)
    .catch(() => null);

  const results = [];
  let savedCount = 0;

  for (const item of items) {
    let result;
    try {
      await activateTabForSave(item.tabId);
      const saveResult = await clickSaveOnTab(item.tabId);
      result = saveResult?.ok
        ? { tabId: item.tabId, title: item.title, ok: true }
        : { tabId: item.tabId, title: item.title, ok: false, reason: saveResult?.reason || 'unknown error' };
    } catch (error) {
      result = { tabId: item.tabId, title: item.title, ok: false, reason: error.message || 'unexpected error' };
    }

    if (result.ok) savedCount += 1;
    results.push(result);
    broadcastBulkSaveProgress(result);
  }

  if (originalActiveTab?.id != null) {
    try {
      if (originalActiveTab.windowId != null) {
        await chrome.windows.update(originalActiveTab.windowId, { focused: true });
      }
      await chrome.tabs.update(originalActiveTab.id, { active: true });
    } catch {
      // Best-effort - e.g. the original tab was closed during the run.
    }
  }

  const summary = { total: items.length, savedCount, results, completedAt: Date.now() };
  try {
    await chrome.storage.local.set({ lagidiskonLastBulkSave: summary });
  } catch {
    // Best-effort - losing the recovery record isn't worth failing the run.
  }
  return summary;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'BULK_SAVE_TABS') {
    const items = Array.isArray(message.items) ? message.items : [];
    runBulkSave(items).then((summary) => sendResponse({ ok: true, ...summary }));
    return true;
  }

  if (message?.type === 'READ_ACTIVE_TAB') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const [tab] = tabs;
      sendResponse({
        ok: true,
        url: tab?.url ?? null,
        title: tab?.title ?? null
      });
    });
    return true;
  }

  if (message?.type === 'VALIDATE_CONFIG') {
    const sources = Array.isArray(message.sources) ? message.sources : [];
    const issues = sources
      .filter((value) => typeof value === 'string' && value.trim())
      .map((value) => value.trim())
      .filter((value) => {
        try {
          const url = new URL(value);
          return ['http:', 'https:'].includes(url.protocol);
        } catch {
          return true;
        }
      });

    sendResponse({
      ok: issues.length === 0,
      invalidCount: issues.length
    });
    return true;
  }

  return false;
});
