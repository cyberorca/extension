const test = require('node:test');
const assert = require('node:assert/strict');
const {
  isLikelyGAMPage,
  resolveWriteTarget,
  validateTargetState,
  updateCustomCreativeFetchUrl,
  replaceFetchUrlInEditor
} = require('./gam-helpers.js');

function mockDocumentWithFields(fields) {
  const all = fields.map((field) => ({
    ...field,
    value: field.value || '',
    getAttribute(name) {
      return field.attributes?.[name] ?? null;
    }
  }));

  return {
    querySelectorAll(selector) {
      return all.filter((field) => {
        const name = (field.name || '').toLowerCase();
        const id = (field.id || '').toLowerCase();
        const label = (field.label || '').toLowerCase();
        const placeholder = (field.placeholder || '').toLowerCase();
        const haystacks = [name, id, label, placeholder].join(' ');
        return haystacks.includes('json') || haystacks.includes('url');
      });
    }
  };
}

test('isLikelyGAMPage detects Google Ad Manager URLs', () => {
  assert.equal(isLikelyGAMPage('https://admanager.google.com/1234567#creatives'), true);
  assert.equal(isLikelyGAMPage('https://example.com/some-page'), false);
});

test('resolveWriteTarget picks the most likely JSON field', () => {
  const doc = mockDocumentWithFields([
    { name: 'creativeName', value: 'abc' },
    { name: 'jsonUrl', value: 'https://cdn.example.com/data.json' },
    { id: 'creative-url', value: '' }
  ]);

  const target = resolveWriteTarget(doc);
  assert.equal(target?.name, 'jsonUrl');
});

test('validateTargetState rejects missing field and stale page state', () => {
  const missing = validateTargetState({ pageIsStale: true, target: null });
  assert.equal(missing.ok, false);
  assert.match(missing.reason, /stale|missing/i);

  const good = validateTargetState({ pageIsStale: false, target: { value: 'old' } });
  assert.equal(good.ok, true);
});

function makeCustomDoc(editorNode) {
  return {
    querySelectorAll(selector) {
      if (selector === '.subheader-item') {
        return [{ textContent: 'Creative type: Custom' }];
      }
      if (selector === '.CodeMirror') {
        return [];
      }
      if (selector === 'textarea, input, [contenteditable="true"]') {
        return [editorNode];
      }
      return [];
    }
  };
}

test('updateCustomCreativeFetchUrl rejects non-custom creatives', () => {
  const editor = {
    tagName: 'TEXTAREA',
    value: 'fetch("")',
    dispatchEvent() {}
  };

  const nonCustomDoc = {
    querySelectorAll(selector) {
      if (selector === '.subheader-item') {
        return [{ textContent: 'Creative type: Third party' }];
      }
      if (selector === '.CodeMirror') return [];
      return [editor];
    }
  };

  const result = updateCustomCreativeFetchUrl(nonCustomDoc, 'https://cdn.example.com/site.json');
  assert.equal(result.ok, false);
  assert.match(result.reason, /not a custom creative/i);
});

test('updateCustomCreativeFetchUrl fills a freshly-templated empty fetch("")', () => {
  const editor = { tagName: 'TEXTAREA', value: 'fetch("")', dispatchEvent() {} };
  const doc = makeCustomDoc(editor);

  const result = updateCustomCreativeFetchUrl(doc, 'https://cdn.example.com/site.json');
  assert.equal(result.ok, true);
  assert.match(editor.value, /fetch\("https:\/\/cdn\.example\.com\/site\.json"\)/);
});

test('updateCustomCreativeFetchUrl replaces an EXISTING fetch URL, not just an empty one', () => {
  const editor = {
    tagName: 'TEXTAREA',
    value: 'const data = await fetch("https://old-cdn.example.com/stale.json").then(r => r.json());',
    dispatchEvent() {}
  };
  const doc = makeCustomDoc(editor);

  const result = updateCustomCreativeFetchUrl(doc, 'https://cdn.example.com/new-site.json');
  assert.equal(result.ok, true);
  assert.match(editor.value, /fetch\("https:\/\/cdn\.example\.com\/new-site\.json"\)/);
  assert.doesNotMatch(editor.value, /old-cdn\.example\.com/);
});

test('updateCustomCreativeFetchUrl writes through the CodeMirror API, not raw DOM text', () => {
  const calls = [];
  const cmInstance = {
    lineCount: () => 2,
    getLine: (i) => (i === 1 ? 'fetch("https://old.example.com/a.json")' : 'const x = 1;'),
    replaceRange: (text, from, to) => calls.push({ text, from, to })
  };

  const doc = {
    querySelectorAll(selector) {
      if (selector === '.subheader-item') {
        return [{ textContent: 'Creative type: Custom' }];
      }
      if (selector === '.CodeMirror') {
        return [{ CodeMirror: cmInstance }];
      }
      return [];
    }
  };

  const result = updateCustomCreativeFetchUrl(doc, 'https://cdn.example.com/new.json');
  assert.equal(result.ok, true);
  assert.equal(result.node, 'CodeMirror');
  assert.equal(calls.length, 1);
  // Only the quoted URL itself is replaced now (not the whole line/fetch(
  // token), so the write survives whatever formatting surrounds it.
  assert.equal(calls[0].text, 'https://cdn.example.com/new.json');
});

test('updateCustomCreativeFetchUrl finds and replaces a fetch(...) call WRAPPED ACROSS MULTIPLE LINES', () => {
  // Reproduces the real-world bug report: "No fetch(...) call was found in
  // the custom creative code editor." - the previous line-by-line scan
  // missed this because no single line contains both `fetch(` and the
  // quoted URL.
  const sourceLines = [
    'const data = await fetch(',
    '  "https://old-cdn.example.com/stale.json"',
    ').then((r) => r.json());'
  ];

  const calls = [];
  const cmInstance = {
    lineCount: () => sourceLines.length,
    getLine: (i) => sourceLines[i],
    replaceRange: (text, from, to) => calls.push({ text, from, to })
  };

  const doc = {
    querySelectorAll(selector) {
      if (selector === '.subheader-item') {
        return [{ textContent: 'Creative type: Custom' }];
      }
      if (selector === '.CodeMirror') {
        return [{ CodeMirror: cmInstance }];
      }
      return [];
    }
  };

  const result = updateCustomCreativeFetchUrl(doc, 'https://cdn.example.com/new-site.json');
  assert.equal(result.ok, true);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].text, 'https://cdn.example.com/new-site.json');
  // The quoted content sits entirely on line 1 (0-indexed), inside the
  // two-space indent, between the two double-quote characters.
  assert.deepEqual(calls[0].from, { line: 1, ch: 3 });
  assert.deepEqual(calls[0].to, { line: 1, ch: 3 + 'https://old-cdn.example.com/stale.json'.length });
});

test('updateCustomCreativeFetchUrl detects a GAM macro placeholder and refuses to overwrite it', () => {
  const cmInstance = {
    lineCount: () => 1,
    getLine: () => 'const data = await fetch("%%FILE:MACRO2%%").then(r => r.json());',
    replaceRange: () => { throw new Error('should not be called - placeholder must not be overwritten'); }
  };

  const doc = {
    querySelectorAll(selector) {
      if (selector === '.subheader-item') {
        return [{ textContent: 'Creative type: Custom' }];
      }
      if (selector === '.CodeMirror') {
        return [{ CodeMirror: cmInstance }];
      }
      return [];
    }
  };

  const result = updateCustomCreativeFetchUrl(doc, 'https://cdn.example.com/new.json');
  assert.equal(result.ok, false);
  assert.equal(result.isMacroPlaceholder, true);
  assert.equal(result.macroName, 'Macro 2');
  assert.equal(result.macroPlaceholder, '%%FILE:MACRO2%%');
  assert.match(result.reason, /macro placeholder/i);
});

function makePanel({ title = '', subtitle = '', removeControl = null } = {}) {
  return {
    querySelector(selector) {
      if (selector === '.file-info .title' || selector === '.title') return title ? { textContent: title } : null;
      if (selector === '.file-info .subtitle' || selector === '.subtitle') return subtitle ? { textContent: subtitle } : null;
      return null;
    },
    querySelectorAll() {
      return removeControl ? [removeControl] : [];
    },
    closest: null // set per-test where needed
  };
}

test('findJsonMacroPanel finds the macro slot whose uploaded file TITLE is a .json, not by name/number', () => {
  const { findJsonMacroPanel } = require('./gam-helpers.js');

  const imagePanel = makePanel({ title: 'fallback-creative.png', subtitle: '12 KB' });
  const jsonPanel = makePanel({ title: 'bola-net-source.json', subtitle: '4 KB' });

  const doc = {
    querySelectorAll(selector) {
      if (selector === 'file-detail-panel') return [imagePanel, jsonPanel];
      return [];
    }
  };

  const match = findJsonMacroPanel(doc);
  assert.equal(match.panel, jsonPanel);
  assert.equal(match.fileName, 'bola-net-source.json');
});

test('findJsonMacroPanel falls back to the subtitle when a panel has no .title', () => {
  const { findJsonMacroPanel } = require('./gam-helpers.js');
  const jsonPanel = makePanel({ subtitle: 'merdeka-source.json' });
  const doc = { querySelectorAll: (selector) => (selector === 'file-detail-panel' ? [jsonPanel] : []) };

  const match = findJsonMacroPanel(doc);
  assert.equal(match.fileName, 'merdeka-source.json');
});

test('findJsonMacroPanel returns null when no macro slot holds a .json file', () => {
  const { findJsonMacroPanel } = require('./gam-helpers.js');
  const imagePanel = makePanel({ title: 'fallback-creative.png' });
  const doc = { querySelectorAll: () => [imagePanel] };
  assert.equal(findJsonMacroPanel(doc), null);
});

test('findRemoveControlForPanel finds a remove/delete control within the panel by label', () => {
  const { findRemoveControlForPanel } = require('./gam-helpers.js');
  const removeButton = { getAttribute: (name) => (name === 'aria-label' ? 'Remove file' : null), textContent: '' };
  const panel = { querySelectorAll: () => [removeButton] };
  assert.equal(findRemoveControlForPanel(panel), removeButton);
});

test('uploadJsonMacroReplacement removes the existing file, reuploads under the SAME original name, and dispatches change', () => {
  const { uploadJsonMacroReplacement } = require('./gam-helpers.js');

  const fileInput = {
    type: 'file',
    files: null,
    changeEvents: 0,
    dispatchEvent(event) {
      if (event.type === 'change') this.changeEvents += 1;
      return true;
    }
  };
  const fieldScope = { querySelector: (selector) => (selector === 'input[type="file"]' ? fileInput : null) };
  const removeControl = { clicked: false, click() { this.clicked = true; }, getAttribute: (n) => (n === 'aria-label' ? 'Remove' : null), textContent: '' };

  const jsonPanel = makePanel({ title: 'bola-net-source.json', removeControl });
  jsonPanel.closest = (selector) => (selector === 'drx-form-field' ? fieldScope : null);

  const doc = {
    querySelectorAll(selector) {
      if (selector === 'file-detail-panel') return [jsonPanel];
      return [];
    }
  };

  // Even though a different fileName default is passed in, the ORIGINAL
  // panel title ("bola-net-source.json") must win, to avoid ending up with
  // two .json entries listed side by side.
  const result = uploadJsonMacroReplacement(doc, 'macro.json', '{"json_url":"https://cdn.example.com/a.json"}');

  assert.equal(result.ok, true);
  assert.equal(removeControl.clicked, true);
  assert.equal(result.removedExisting, true);
  assert.equal(result.previousFile, 'bola-net-source.json');
  assert.equal(result.fileName, 'bola-net-source.json');
  assert.equal(fileInput.changeEvents, 1);
  assert.ok(fileInput.files);
});

test('uploadJsonMacroReplacement still uploads (best-effort) when no remove control is found', () => {
  const { uploadJsonMacroReplacement } = require('./gam-helpers.js');

  const fileInput = { type: 'file', files: null, dispatchEvent: () => true };
  const fieldScope = { querySelector: (selector) => (selector === 'input[type="file"]' ? fileInput : null) };

  const jsonPanel = makePanel({ title: 'old.json' });
  jsonPanel.closest = (selector) => (selector === 'drx-form-field' ? fieldScope : null);

  const doc = { querySelectorAll: (selector) => (selector === 'file-detail-panel' ? [jsonPanel] : []) };

  const result = uploadJsonMacroReplacement(doc, 'macro.json', '{}');
  assert.equal(result.ok, true);
  assert.equal(result.removedExisting, false);
  assert.equal(result.fileName, 'old.json');
});

test('uploadJsonMacroReplacement gives a specific reason when NO file-detail-panel exists at all', () => {
  const { uploadJsonMacroReplacement } = require('./gam-helpers.js');
  const doc = { querySelectorAll: () => [] };
  const result = uploadJsonMacroReplacement(doc);
  assert.equal(result.ok, false);
  assert.equal(result.panelCount, 0);
  assert.match(result.reason, /No <file-detail-panel> elements were found/);
});

test('uploadJsonMacroReplacement lists what WAS found when panels exist but none are .json', () => {
  const { uploadJsonMacroReplacement } = require('./gam-helpers.js');
  const imagePanel = makePanel({ title: 'fallback-creative.png' });
  const emptyPanel = makePanel({});
  const doc = { querySelectorAll: (selector) => (selector === 'file-detail-panel' ? [imagePanel, emptyPanel] : []) };

  const result = uploadJsonMacroReplacement(doc);
  assert.equal(result.ok, false);
  assert.equal(result.panelCount, 2);
  assert.match(result.reason, /fallback-creative\.png/);
  assert.match(result.reason, /no title\/subtitle text found/);
});

test('findJsonMacroPanel falls back to scanning full panel text when no .title/.subtitle node exists', () => {
  const { findJsonMacroPanel } = require('./gam-helpers.js');
  const panel = {
    querySelector: () => null,
    textContent: 'Uploaded file: source-data.json (3.1 KB) — replace'
  };
  const doc = { querySelectorAll: (selector) => (selector === 'file-detail-panel' ? [panel] : []) };

  const match = findJsonMacroPanel(doc);
  assert.ok(match);
  assert.equal(match.fileName, 'source-data.json');
});

test('macroPlaceholderToDisplayName formats macro names to match GAM row labels', () => {
  const { macroPlaceholderToDisplayName } = require('./gam-helpers.js');
  assert.equal(macroPlaceholderToDisplayName('MACRO2'), 'Macro 2');
  assert.equal(macroPlaceholderToDisplayName('MACRO10'), 'Macro 10');
  assert.equal(macroPlaceholderToDisplayName(''), 'Macro 1');
});

test('replaceFetchUrlInEditor returns false when there is no fetch(...) call', () => {
  const cmInstance = {
    lineCount: () => 1,
    getLine: () => 'console.log("no fetch here");',
    replaceRange: () => { throw new Error('should not be called'); }
  };

  assert.equal(replaceFetchUrlInEditor(cmInstance, 'https://cdn.example.com/x.json'), false);
});

test('removeMacroByName removes the macro row named macro 1 and uploadMacroFile populates the file input', () => {
  const macroNodes = [
    { textContent: 'Macro 1', click() { this.removed = true; } },
    { textContent: 'Macro 2', click() { this.removed = true; } }
  ];

  const fileInput = {
    type: 'file',
    files: null,
    dispatchEvent() { return true; }
  };

  const doc = {
    querySelectorAll(selector) {
      if (selector.includes('button') || selector.includes('macro') || selector.includes('role') || selector.includes('aria-label')) {
        return macroNodes;
      }
      return [];
    },
    querySelector(selector) {
      if (selector.includes('input[type="file"]') || selector.includes('input[type="file"][accept]') || selector.includes('browse-button')) {
        return fileInput;
      }
      return null;
    }
  };

  const { removeMacroByName, uploadMacroFile, buildMacroUploadFile } = require('./gam-helpers.js');
  const removed = removeMacroByName(doc, 'macro 1');
  const prepared = buildMacroUploadFile('macro 1', '{"ok":true}');
  const uploaded = uploadMacroFile(doc, 'macro 1', prepared);

  assert.equal(removed.ok, true);
  assert.equal(prepared instanceof File || prepared instanceof Blob, true);
  assert.equal(uploaded.ok, true);
  assert.equal(uploaded.fileName, 'macro 1');
});

test('buildMacroUploadFile reconstructs a File from a transferable base64 payload', () => {
  const { buildMacroUploadFile } = require('./gam-helpers.js');
  const original = Buffer.from('{"json_url":"https://cdn.example.com/a.json"}', 'utf8').toString('base64');
  const file = buildMacroUploadFile('macro 1', { base64: original, type: 'application/json' });

  assert.equal(file instanceof File, true);
  assert.equal(file.name, 'macro 1');
  assert.equal(file.type, 'application/json');
});

// ---------------------------------------------------------------------------
// End-to-end: a custom creative whose fetch(...) references a GAM macro
// placeholder (%%FILE:MACRO2%%), reproducing the exact scenario reported -
// the code editor must be left completely untouched, and the .json macro
// slot must be found and replaced instead. Panel mocks match the REAL
// getPanelTitleText/getPanelSubtitleText implementation (nested firstChild
// text node, subtitle split on "|") and the real addSaltToFilename output.
// ---------------------------------------------------------------------------
test('end-to-end: %%FILE:MACRO2%% placeholder is left alone, and the .json macro slot is uploaded instead', () => {
  const {
    updateCustomCreativeFetchUrl,
    uploadJsonMacroReplacement
  } = require('./gam-helpers.js');

  // --- The custom creative's code editor -----------------------------
  const cmInstance = {
    lineCount: () => 1,
    getLine: () => 'const data = await fetch("%%FILE:MACRO2%%").then(r => r.json());',
    replaceRange: () => {
      throw new Error('the code editor must NOT be written to - this is the exact bug being guarded against');
    }
  };

  // --- The macro upload widget: MACRO2's slot currently holds a .json -
  const fileInput = {
    type: 'file',
    files: null,
    changeEvents: 0,
    dispatchEvent(event) {
      if (event.type === 'change') this.changeEvents += 1;
      return true;
    }
  };
  const fieldScope = { querySelector: (selector) => (selector === 'input[type="file"]' ? fileInput : null) };
  const removeControl = { clicked: false, click() { this.clicked = true; }, getAttribute: (n) => (n === 'aria-label' ? 'Remove' : null), textContent: '' };

  const jsonPanel = {
    querySelector(selector) {
      if (selector === '.file-info .title' || selector === '.title') {
        return { firstChild: { textContent: 'bola-net-source.json' } };
      }
      if (selector === '.file-info .subtitle' || selector === '.subtitle') {
        // Format includes the "|" separator the real getPanelSubtitleText()
        // splits on. Title is read first and wins when present; subtitle is
        // only the fallback for panels with no distinct title node.
        return { firstChild: { textContent: 'bola-net-source.json | 4.1 KB' } };
      }
      return null;
    },
    querySelectorAll: () => [removeControl],
    closest: (selector) => (selector === 'drx-form-field' ? fieldScope : null)
  };

  const doc = {
    querySelectorAll(selector) {
      if (selector === '.subheader-item') return [{ textContent: 'Creative type: Custom' }];
      if (selector === '.CodeMirror') return [{ CodeMirror: cmInstance }];
      if (selector === 'file-detail-panel') return [jsonPanel];
      return [];
    }
  };

  // Step 1: the app tries the direct custom-creative edit first, exactly
  // as applySmartUpdate() does.
  const editResult = updateCustomCreativeFetchUrl(doc, 'https://cdn.example.com/new-source.json');
  assert.equal(editResult.ok, false);
  assert.equal(editResult.isMacroPlaceholder, true);
  assert.equal(editResult.macroPlaceholder, '%%FILE:MACRO2%%');
  // cmInstance.replaceRange throwing (rather than the test failing on a
  // missed call) is itself proof the editor was never written to.

  // Step 2: since it's a placeholder, applySmartUpdate() falls through to
  // the content-based macro upload instead of editing code.
  const uploadResult = uploadJsonMacroReplacement(doc, 'macro.json', '{"json_url":"https://cdn.example.com/new-source.json"}');
  assert.equal(uploadResult.ok, true);
  assert.equal(removeControl.clicked, true);
  // The existing file is removed BEFORE the new one is uploaded, so
  // re-using the exact original filename is safe (no collision) and is
  // required, not optional: GAM's upload widget appends a new entry rather
  // than replacing in place, so any filename other than the original would
  // leave two separate .json files listed side by side.
  assert.equal(uploadResult.previousFile, 'bola-net-source.json');
  assert.equal(uploadResult.fileName, 'bola-net-source.json');
  assert.equal(fileInput.changeEvents, 1);
});

// ---------------------------------------------------------------------
// Label-based lookup - the "field has never had a file uploaded" case,
// where no <file-detail-panel> exists yet for findJsonMacroPanel() to find.
// ---------------------------------------------------------------------

function makeFormField({ label = '', fileInput = null } = {}) {
  return {
    querySelector(selector) {
      if (selector === 'drx-form-field-label .field-label, .field-label') {
        return label ? { textContent: label } : null;
      }
      if (selector === 'input[type="file"]') {
        return fileInput;
      }
      return null;
    }
  };
}

test('findFormFieldByLabel matches a drx-form-field by its rendered label text', () => {
  const { findFormFieldByLabel } = require('./gam-helpers.js');
  const jsonField = makeFormField({ label: 'Json File' });
  const otherField = makeFormField({ label: 'Click URL' });

  const doc = { querySelectorAll: (selector) => (selector === 'drx-form-field' ? [otherField, jsonField] : []) };

  assert.equal(findFormFieldByLabel(doc, 'Json File'), jsonField);
  assert.equal(findFormFieldByLabel(doc, 'json file'), jsonField); // case-insensitive
});

test('findUploadInputForLabel returns the file input scoped to the labeled field, not just the first on the page', () => {
  const { findUploadInputForLabel } = require('./gam-helpers.js');
  const correctInput = { type: 'file', which: 'json' };
  const otherInput = { type: 'file', which: 'image' };

  const jsonField = makeFormField({ label: 'Json File', fileInput: correctInput });
  const imageField = makeFormField({ label: 'Fallback Image', fileInput: otherInput });

  const doc = { querySelectorAll: (selector) => (selector === 'drx-form-field' ? [imageField, jsonField] : []) };

  assert.equal(findUploadInputForLabel(doc, 'Json File'), correctInput);
});

test('uploadJsonByFieldLabel uploads directly into a field that has never had a file, with no remove step', () => {
  const { uploadJsonByFieldLabel } = require('./gam-helpers.js');
  const fileInput = { type: 'file', files: null, dispatchEvent: () => true };
  const jsonField = makeFormField({ label: 'Json File', fileInput });
  const doc = { querySelectorAll: (selector) => (selector === 'drx-form-field' ? [jsonField] : []) };

  const result = uploadJsonByFieldLabel(doc, 'Json File', 'macro.json', '{"json_url":"https://cdn.example.com/a.json"}');
  assert.equal(result.ok, true);
  assert.equal(result.removedExisting, false);
  assert.equal(result.fileName, 'macro.json');
  assert.ok(fileInput.files);
});

test('uploadJsonByFieldLabel fails clearly when no field matches the label', () => {
  const { uploadJsonByFieldLabel } = require('./gam-helpers.js');
  const doc = { querySelectorAll: () => [] };
  const result = uploadJsonByFieldLabel(doc, 'Json File');
  assert.equal(result.ok, false);
  assert.match(result.reason, /No upload input was found for the "Json File" field/);
});

test('uploadJsonMacroFile falls back to the label-based first upload when no file-detail-panel exists at all', async () => {
  const { uploadJsonMacroFile } = require('./gam-helpers.js');
  const fileInput = { type: 'file', files: null, dispatchEvent: () => true };
  const jsonField = makeFormField({ label: 'Json File', fileInput });

  const doc = {
    querySelectorAll(selector) {
      if (selector === 'file-detail-panel') return []; // never uploaded before
      if (selector === 'drx-form-field') return [jsonField];
      return [];
    }
  };

  const result = await uploadJsonMacroFile(doc, 'macro.json', '{}', { labelText: 'Json File' });
  assert.equal(result.ok, true);
  assert.equal(result.removedExisting, false);
});

test('uploadJsonMacroFile does NOT fall back to the label path when panels exist but none are .json (a real problem, not a timing gap)', async () => {
  const { uploadJsonMacroFile } = require('./gam-helpers.js');
  const imagePanel = makePanel({ title: 'fallback-creative.png' });
  const doc = { querySelectorAll: (selector) => (selector === 'file-detail-panel' ? [imagePanel] : []) };

  const result = await uploadJsonMacroFile(doc, 'macro.json', '{}');
  assert.equal(result.ok, false);
  assert.equal(result.panelCount, 1);
  assert.match(result.reason, /none currently show a \.json file/);
});

test('waitForElement resolves immediately when the element already exists (no MutationObserver needed)', async () => {
  const { waitForElement } = require('./gam-helpers.js');
  const found = await waitForElement({}, () => 'already-there');
  assert.equal(found, 'already-there');
});

test('waitForElement rejects cleanly when the element is missing and there is no way to observe for it', async () => {
  const { waitForElement } = require('./gam-helpers.js');
  await assert.rejects(
    () => waitForElement({}, () => null, { root: null }),
    /No observable root available/
  );
});

test('uploadJsonMacroReplacementAsync waits for a NEW input after remove swaps the widget back to its empty state', async () => {
  const { uploadJsonMacroReplacementAsync } = require('./gam-helpers.js');

  const newFileInput = {
    type: 'file',
    files: null,
    changeEvents: 0,
    dispatchEvent(event) {
      if (event.type === 'change') this.changeEvents += 1;
      return true;
    }
  };
  let widgetWasReset = false;

  const fieldScope = {
    querySelector(selector) {
      if (selector !== 'input[type="file"]') return null;
      // Simulates Angular swapping the whole upload widget's subtree back
      // to its empty state the instant remove is clicked - the ORIGINAL
      // input is gone; only a brand-new one exists, and only after click.
      return widgetWasReset ? newFileInput : null;
    }
  };

  const removeControl = {
    clicked: false,
    click() {
      this.clicked = true;
      widgetWasReset = true;
    },
    getAttribute: (n) => (n === 'aria-label' ? 'Remove' : null),
    textContent: ''
  };

  const jsonPanel = makePanel({ title: 'bola-net-source.json', removeControl });
  jsonPanel.closest = (selector) => (selector === 'drx-form-field' ? fieldScope : null);

  const doc = { querySelectorAll: (selector) => (selector === 'file-detail-panel' ? [jsonPanel] : []) };

  const result = await uploadJsonMacroReplacementAsync(doc, 'macro.json', '{}', { timeoutMs: 1000 });

  assert.equal(result.ok, true);
  assert.equal(result.fileName, 'bola-net-source.json');
  assert.equal(result.input, newFileInput);
  assert.equal(newFileInput.changeEvents, 1);
});

test('uploadJsonMacroReplacementAsync reports a clear error when the upload field never reappears after removal', async () => {
  const { uploadJsonMacroReplacementAsync } = require('./gam-helpers.js');

  const fieldScope = { querySelector: () => null }; // never reappears
  const removeControl = {
    clicked: false,
    click() { this.clicked = true; },
    getAttribute: (n) => (n === 'aria-label' ? 'Remove' : null),
    textContent: ''
  };

  const jsonPanel = makePanel({ title: 'bola-net-source.json', removeControl });
  jsonPanel.closest = (selector) => (selector === 'drx-form-field' ? fieldScope : null);

  const doc = { querySelectorAll: (selector) => (selector === 'file-detail-panel' ? [jsonPanel] : []) };

  const result = await uploadJsonMacroReplacementAsync(doc, 'macro.json', '{}', { timeoutMs: 50 });

  assert.equal(result.ok, false);
  assert.match(result.reason, /Removed the existing "bola-net-source\.json"/);
});

// ---------------------------------------------------------------------------
// Save and preview
// ---------------------------------------------------------------------------

test('findSaveAndPreviewButton matches by stable class + visible label text, ignoring Angular content hashes', () => {
  const { findSaveAndPreviewButton } = require('./gam-helpers.js');

  const backButton = {
    querySelector: () => ({ textContent: 'Back' }),
    textContent: 'Back'
  };
  const saveButton = {
    querySelector: () => ({ textContent: 'Save and preview' }),
    textContent: 'Save and preview'
  };

  const doc = {
    querySelectorAll(selector) {
      if (selector.includes('btn-yes') || selector.includes('material-button')) {
        return [backButton, saveButton];
      }
      return [];
    }
  };

  assert.equal(findSaveAndPreviewButton(doc), saveButton);
});

test('findSaveAndPreviewButton returns null when no matching button is present', () => {
  const { findSaveAndPreviewButton } = require('./gam-helpers.js');
  const doc = { querySelectorAll: () => [] };
  assert.equal(findSaveAndPreviewButton(doc), null);
});

test('clickSaveAndPreview clicks the button host element (not just its inner .content div)', () => {
  const { clickSaveAndPreview } = require('./gam-helpers.js');

  let clicked = false;
  const saveButton = {
    querySelector: () => ({ textContent: 'Save and preview' }),
    textContent: 'Save and preview',
    click() { clicked = true; }
  };

  const doc = { querySelectorAll: () => [saveButton] };

  const result = clickSaveAndPreview(doc);
  assert.equal(result.ok, true);
  assert.equal(clicked, true);
});

test('clickSaveAndPreview fails clearly when the button is not found', () => {
  const { clickSaveAndPreview } = require('./gam-helpers.js');
  const doc = { querySelectorAll: () => [] };
  const result = clickSaveAndPreview(doc);
  assert.equal(result.ok, false);
  assert.match(result.reason, /not found/);
});
