(function (global) {
  function isGAMTabUrl(url = '') {
    const href = String(url || '').toLowerCase();
    return href.includes('admanager.google.com') || href.includes('google.com/dfp') || href.includes('googleadmanager');
  }

  function buildTabQueue(tabs = []) {
    return (tabs || [])
      .filter((tab) => tab && tab.id && isGAMTabUrl(tab.url))
      .map((tab) => ({
        tabId: tab.id,
        title: tab.title || `Tab ${tab.id}`,
        url: tab.url || '',
        status: 'pending',
        mode: '',
        lastError: ''
      }));
  }

  function getRetryQueue(queue = []) {
    return (queue || []).filter((item) => item && item.status === 'failed');
  }

  const api = {
    isGAMTabUrl,
    buildTabQueue,
    getRetryQueue
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }

  global.BATCH_HELPERS = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
