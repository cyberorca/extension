const test = require('node:test');
const assert = require('node:assert/strict');
const {
  normalizeGoogleDriveUrl,
  extractUrlsFromPayload,
  extractSourceEntriesFromPayload,
  expandSourceEntries,
  resolveSiteFromCreativeName,
  resolveSourceFromCreativeName,
  isGoogleSheetsUrl,
  extractSheetIdAndGid,
  normalizeGoogleSheetsCsvUrl,
  parseCsv,
  extractSourceEntriesFromCsv,
  loadSourceEntriesFromUrl
} = require('./source-list.js');

test('normalizeGoogleDriveUrl converts a Drive view URL into a downloadable file URL', () => {
  const value = 'https://drive.google.com/file/d/1je54X0abTr10oA-0u0jx8Cnpxg8adBLD/view';
  assert.equal(
    normalizeGoogleDriveUrl(value),
    'https://drive.google.com/uc?export=download&id=1je54X0abTr10oA-0u0jx8Cnpxg8adBLD'
  );
});

test('extractUrlsFromPayload flattens JSON arrays and nested objects into source URL candidates', () => {
  const payload = {
    sources: [
      'https://cdn.example.com/a.json',
      { url: 'https://cdn.example.com/b.json' },
      { item: { value: 'https://cdn.example.com/c.json' } }
    ]
  };

  assert.deepEqual(extractUrlsFromPayload(payload), [
    'https://cdn.example.com/a.json',
    'https://cdn.example.com/b.json',
    'https://cdn.example.com/c.json'
  ]);
});

test('expandSourceEntries resolves list-driven JSON URLs into concrete source entries', async () => {
  const originalFetch = globalThis.fetch;

  globalThis.fetch = async () => ({
    ok: true,
    json: async () => ({
      sources: [
        'https://cdn.example.com/a.json',
        'https://cdn.example.com/b.json'
      ]
    })
  });

  try {
    const result = await expandSourceEntries([
      { id: 'source1', site: 'Site A', value: 'https://drive.google.com/file/d/1je54X0abTr10oA-0u0jx8Cnpxg8adBLD/view' }
    ]);

    assert.deepEqual(result.map((item) => item.value), [
      'https://cdn.example.com/a.json',
      'https://cdn.example.com/b.json'
    ]);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('extractSourceEntriesFromPayload reads name/json_url objects from a list payload', () => {
  const payload = [
    { name: 'kapanlagi.com', json_url: 'https://example.com/site1/data.json' },
    { name: 'bola.net', json_url: 'https://example.com/site2/data.json' },
    { name: 'liputan6.com', json_url: 'https://example.com/site3/data.json' }
  ];

  assert.deepEqual(extractSourceEntriesFromPayload(payload), [
    { name: 'kapanlagi.com', site: 'kapanlagi.com', json_url: 'https://example.com/site1/data.json' },
    { name: 'bola.net', site: 'bola.net', json_url: 'https://example.com/site2/data.json' },
    { name: 'liputan6.com', site: 'liputan6.com', json_url: 'https://example.com/site3/data.json' }
  ]);
});

test('resolveSiteFromCreativeName picks the matching site alias from the creative title', () => {
  const creativeName = '# [OMP] | [LagiDiskon ] [Desktop Masthead] | Affiliate BOLANET';
  const matched = resolveSiteFromCreativeName(creativeName, [
    { site: 'liputan6', name: 'Liputan6' },
    { site: 'bola.net', name: 'Bola.net' },
    { site: 'fimela', name: 'Fimela' }
  ]);

  assert.equal(matched.site, 'bola.net');
  assert.equal(matched.name, 'Bola.net');
});

test('resolveSourceFromCreativeName returns the correct json_url for the matched site alias', () => {
  const creativeName = '# [OMP] | [LagiDiskon ] [Desktop Masthead] | Affiliate BOLANET';
  const payload = [
    { name: 'Liputan6', site: 'liputan6', json_url: 'https://cdn.example.com/liputan6.json' },
    { name: 'Bola.net', site: 'bola.net', json_url: 'https://cdn.example.com/bola.net.json' },
    { name: 'Fimela', site: 'fimela', json_url: 'https://cdn.example.com/fimela.json' }
  ];

  const match = resolveSourceFromCreativeName(payload, creativeName);
  assert.equal(match.json_url, 'https://cdn.example.com/bola.net.json');
  assert.equal(match.site, 'bola.net');
});

// ---------------------------------------------------------------------------
// Google Sheets source support
// ---------------------------------------------------------------------------

test('isGoogleSheetsUrl recognizes a Sheets edit URL and rejects a Drive file URL', () => {
  assert.equal(isGoogleSheetsUrl('https://docs.google.com/spreadsheets/d/16RwrkdLhEwyPO24ONMv1nBlFkHANuwZaFFjxh9E0jMo/edit?usp=sharing'), true);
  assert.equal(isGoogleSheetsUrl('https://drive.google.com/file/d/1je54X0abTr10oA-0u0jx8Cnpxg8adBLD/view'), false);
});

test('normalizeGoogleSheetsCsvUrl converts an edit URL to the CSV export endpoint, defaulting gid to 0', () => {
  const editUrl = 'https://docs.google.com/spreadsheets/d/16RwrkdLhEwyPO24ONMv1nBlFkHANuwZaFFjxh9E0jMo/edit?usp=sharing';
  assert.equal(
    normalizeGoogleSheetsCsvUrl(editUrl),
    'https://docs.google.com/spreadsheets/d/16RwrkdLhEwyPO24ONMv1nBlFkHANuwZaFFjxh9E0jMo/export?format=csv&gid=0'
  );
});

test('extractSheetIdAndGid reads an explicit gid from the URL when present', () => {
  const url = 'https://docs.google.com/spreadsheets/d/ABC123/edit#gid=456';
  assert.deepEqual(extractSheetIdAndGid(url), { id: 'ABC123', gid: '456' });
});

test('parseCsv handles quoted fields containing commas and escaped quotes', () => {
  const csv = 'site,url\n"Liputan6, Inc.","https://cdn.example.com/l6.json"\n"Say ""Hi""",https://cdn.example.com/hi.json';
  assert.deepEqual(parseCsv(csv), [
    ['site', 'url'],
    ['Liputan6, Inc.', 'https://cdn.example.com/l6.json'],
    ['Say "Hi"', 'https://cdn.example.com/hi.json']
  ]);
});

test('extractSourceEntriesFromCsv reads ONLY the site and url columns, ignoring every other column', () => {
  const csv = [
    'id,site,notes,url,owner',
    '1,liputan6.com,internal note,https://cdn.example.com/liputan6.json,doni',
    '2,bola.net,,https://cdn.example.com/bola.net.json,doni'
  ].join('\n');

  assert.deepEqual(extractSourceEntriesFromCsv(csv), [
    { name: 'liputan6.com', site: 'liputan6.com', json_url: 'https://cdn.example.com/liputan6.json' },
    { name: 'bola.net', site: 'bola.net', json_url: 'https://cdn.example.com/bola.net.json' }
  ]);
});

test('extractSourceEntriesFromCsv skips rows with a missing site or url, and returns [] when headers are absent', () => {
  const csv = 'site,url\nliputan6.com,\n,https://cdn.example.com/x.json\nbola.net,https://cdn.example.com/bola.net.json';
  assert.deepEqual(extractSourceEntriesFromCsv(csv), [
    { name: 'bola.net', site: 'bola.net', json_url: 'https://cdn.example.com/bola.net.json' }
  ]);

  assert.deepEqual(extractSourceEntriesFromCsv('foo,bar\n1,2'), []);
});

test('loadSourceEntriesFromUrl fetches the Sheets CSV export URL and parses site/url when given a Sheets URL', async () => {
  const originalFetch = globalThis.fetch;
  let requestedUrl = '';

  globalThis.fetch = async (url) => {
    requestedUrl = url;
    return {
      ok: true,
      text: async () => 'site,url\nliputan6.com,https://cdn.example.com/liputan6.json\n'
    };
  };

  try {
    const entries = await loadSourceEntriesFromUrl('https://docs.google.com/spreadsheets/d/16RwrkdLhEwyPO24ONMv1nBlFkHANuwZaFFjxh9E0jMo/edit?usp=sharing');
    assert.equal(requestedUrl, 'https://docs.google.com/spreadsheets/d/16RwrkdLhEwyPO24ONMv1nBlFkHANuwZaFFjxh9E0jMo/export?format=csv&gid=0');
    assert.deepEqual(entries, [
      { name: 'liputan6.com', site: 'liputan6.com', json_url: 'https://cdn.example.com/liputan6.json' }
    ]);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('loadSourceEntriesFromUrl still falls back to Drive/JSON behavior for a non-Sheets URL', async () => {
  const originalFetch = globalThis.fetch;

  globalThis.fetch = async () => ({
    ok: true,
    json: async () => [{ name: 'liputan6.com', json_url: 'https://cdn.example.com/liputan6.json' }]
  });

  try {
    const entries = await loadSourceEntriesFromUrl('https://drive.google.com/file/d/1je54X0abTr10oA-0u0jx8Cnpxg8adBLD/view');
    assert.deepEqual(entries, [
      { name: 'liputan6.com', site: 'liputan6.com', json_url: 'https://cdn.example.com/liputan6.json' }
    ]);
  } finally {
    globalThis.fetch = originalFetch;
  }
});
