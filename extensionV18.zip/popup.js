// Source of truth for {site, json_url} entries. Now a Google Sheet (only
// its "site" and "url" columns are read - see source-list.js
// loadSourceEntriesFromUrl/extractSourceEntriesFromCsv); a Drive-hosted JSON
// file still works too if this is ever pointed back at one.
const DEFAULT_SOURCE_LIST_URL = 'https://docs.google.com/spreadsheets/d/16RwrkdLhEwyPO24ONMv1nBlFkHANuwZaFFjxh9E0jMo/edit?usp=sharing';
const SOURCE_LIST_HELPERS = globalThis.SOURCE_LIST_HELPERS || {};
const BATCH_HELPERS = globalThis.BATCH_HELPERS || {};

// ---------------------------------------------------------------------------
// UI element refs - simplified interface: a readiness pill, a circular
// progress ring, two mutually-exclusive mode checkboxes, one Proceed button,
// and a single log textarea. No source/site override fields, no matched-
// source summary, no manual-file input - see README for what changed.
// ---------------------------------------------------------------------------

const readinessPillEl = document.getElementById('readinessPill');
const progressRingFillEl = document.getElementById('progressRingFill');
const progressLabelEl = document.getElementById('progressLabel');
const modeCurrentTabInput = document.getElementById('modeCurrentTab');
const modeAllTabsInput = document.getElementById('modeAllTabs');
const proceedBtn = document.getElementById('proceedBtn');
const logAreaEl = document.getElementById('logArea');

const PROGRESS_RING_CIRCUMFERENCE = 2 * Math.PI * 34;
if (progressRingFillEl) {
  progressRingFillEl.style.strokeDasharray = String(PROGRESS_RING_CIRCUMFERENCE);
}

let isProcessing = false;
let readyState = { ok: false, tabs: [] };

function setReadiness(text, state) {
  if (!readinessPillEl) return;
  readinessPillEl.textContent = text;
  readinessPillEl.className = `status-pill ${state}`;
}

function setProgress(percent, state = 'idle') {
  if (!progressRingFillEl || !progressLabelEl) return;
  progressRingFillEl.classList.remove('indeterminate');
  const clamped = Math.max(0, Math.min(100, percent));
  const offset = PROGRESS_RING_CIRCUMFERENCE * (1 - clamped / 100);
  progressRingFillEl.style.strokeDashoffset = String(offset);
  progressRingFillEl.className = `progress-ring-fill ${state}`;
  progressLabelEl.textContent = `${Math.round(clamped)}%`;
}

function setProgressIndeterminate(state = 'running') {
  if (!progressRingFillEl || !progressLabelEl) return;
  progressRingFillEl.style.strokeDashoffset = String(PROGRESS_RING_CIRCUMFERENCE * 0.25);
  progressRingFillEl.className = `progress-ring-fill indeterminate ${state}`;
  progressLabelEl.textContent = '…';
}

function clearLog() {
  if (logAreaEl) logAreaEl.value = '';
}

function appendLog(line) {
  if (!logAreaEl) return;
  logAreaEl.value = logAreaEl.value ? `${logAreaEl.value}\n${line}` : line;
  logAreaEl.scrollTop = logAreaEl.scrollHeight;
}

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

async function readConfig() {
  const stored = await chrome.storage.local.get('lagidiskonConfig');
  const config = stored.lagidiskonConfig || {};
  return {
    sourceListUrl: config.sourceListUrl || DEFAULT_SOURCE_LIST_URL,
    siteOverride: config.siteOverride || ''
  };
}

// saveConfig() was dropped along with the source-URL/site-override inputs -
// the simplified UI has no fields for them. readConfig() above is untouched
// and still falls back to DEFAULT_DRIVE_SOURCE_URL / no override, so nothing
// downstream (resolveMatchedSourceForTab, applyToAllTabs' preload, etc.)
// - it now falls back to DEFAULT_SOURCE_LIST_URL, the Google Sheet.
// needed to change.

// ---------------------------------------------------------------------------
// Single source of truth for talking to the active GAM tab: try the content
// script first, and if that fails (timing/injection issues) fall back to
// injecting the *real* gam-helpers.js file and calling it directly - instead
// of keeping a second, hand-copied implementation in sync by hand.
// ---------------------------------------------------------------------------

async function invokeGAMTabAction(tabId, type, payload = {}) {
  try {
    const response = await chrome.tabs.sendMessage(tabId, { type, ...payload });
    if (response) return response;
  } catch {
    // fall through to the script-injection fallback below
  }

  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['gam-helpers.js'] });
  } catch (error) {
    return { ok: false, reason: `Could not reach the active GAM tab: ${error.message}` };
  }

  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: async (msgType, msgPayload) => {
        const helpers = window.GAM_HELPERS;
        if (!helpers) {
          return { ok: false, reason: 'GAM helpers could not be loaded on this page.' };
        }

        if (msgType === 'GET_CREATIVE_TYPE') {
          return { ok: true, creativeType: helpers.getCreativeTypeLabel(document) };
        }
        if (msgType === 'UPDATE_CUSTOM_CREATIVE_FETCH_URL') {
          return helpers.updateCustomCreativeFetchUrl(document, msgPayload.value || '');
        }
        if (msgType === 'REMOVE_MACRO_BY_NAME') {
          return helpers.removeMacroByName(document, msgPayload.name || 'macro 1');
        }
        if (msgType === 'UPLOAD_MACRO_FILE') {
          const fileArg = msgPayload.fileBase64
            ? { base64: msgPayload.fileBase64, type: msgPayload.fileType }
            : (msgPayload.file || '');
          return helpers.uploadMacroFile(document, msgPayload.fileName || 'macro 1', fileArg);
        }
        if (msgType === 'UPLOAD_JSON_MACRO_FILE') {
          const fileArg = msgPayload.fileBase64
            ? { base64: msgPayload.fileBase64, type: msgPayload.fileType }
            : (msgPayload.file || '');
          const fileName = msgPayload.fileName || 'macro.json';
          const labelText = msgPayload.labelText || 'Json File';

          let result = await helpers.uploadJsonMacroFile(document, fileName, fileArg, { labelText });
          const notYetRendered = !result.ok && /No upload input was found for the/i.test(result.reason || '');

          if (notYetRendered && typeof helpers.waitForUploadInputForLabel === 'function') {
            try {
              await helpers.waitForUploadInputForLabel(document, labelText, { timeoutMs: 5000 });
              result = helpers.uploadJsonMacroFile(document, fileName, fileArg, { labelText });
            } catch (waitError) {
              result = { ok: false, reason: waitError.message || 'The upload field never rendered in time.' };
            }
          }

          return result;
        }
        if (msgType === 'WRITE_JSON_FIELD') {
          const target = helpers.resolveWriteTarget(document);
          if (!target) return { ok: false, reason: 'No editable JSON field found.' };
          if (typeof target.value === 'string' || typeof target.value === 'number') {
            target.value = msgPayload.value;
          } else {
            target.textContent = msgPayload.value;
          }
          return { ok: true, fieldLabel: target.name || target.id || 'unknown' };
        }
        if (msgType === 'CLICK_SAVE_AND_PREVIEW') {
          return helpers.clickSaveAndPreview(document);
        }

        return { ok: false, reason: `Unsupported action: ${msgType}` };
      },
      args: [type, payload]
    });

    return results?.[0]?.result || { ok: false, reason: 'No result returned from the page fallback.' };
  } catch (fallbackError) {
    return { ok: false, reason: `Could not run the fallback GAM script: ${fallbackError.message}` };
  }
}

// refreshCreativeTypeBadge()/setCreativeTypeBadge() were dropped along with
// the type badge - not part of the simplified component list. The type is
// still available via invokeGAMTabAction(tab.id, 'GET_CREATIVE_TYPE') if a
// future UI wants it back.

// ---------------------------------------------------------------------------
// Source resolution: Google Sheet (site/url columns) or Drive/JSON list ->
// matched {site, json_url}. The Sheets-vs-Drive/JSON detection and the CSV
// parsing itself live in source-list.js (loadSourceEntriesFromUrl) - this is
// now a thin wrapper so that logic has exactly one place to change.
// ---------------------------------------------------------------------------

async function loadSourceEntries(sourceListUrl) {
  if (typeof SOURCE_LIST_HELPERS.loadSourceEntriesFromUrl === 'function') {
    return SOURCE_LIST_HELPERS.loadSourceEntriesFromUrl(sourceListUrl);
  }

  // Fallback for an older source-list.js build that doesn't have the new
  // helper yet - original Drive/JSON-only behavior.
  const normalized = typeof SOURCE_LIST_HELPERS.normalizeGoogleDriveUrl === 'function'
    ? SOURCE_LIST_HELPERS.normalizeGoogleDriveUrl(sourceListUrl)
    : sourceListUrl;

  const response = await fetch(normalized, { cache: 'no-store', credentials: 'include' });
  if (!response.ok) {
    throw new Error(`Unable to fetch the source list (${response.status})`);
  }

  const payload = await response.json();
  return typeof SOURCE_LIST_HELPERS.extractSourceEntriesFromPayload === 'function'
    ? SOURCE_LIST_HELPERS.extractSourceEntriesFromPayload(payload)
    : [];
}

function matchEntryForContext(entries, contextText, siteOverride) {
  if (siteOverride) {
    const needle = siteOverride.toLowerCase();
    const direct = entries.find((entry) => {
      const name = String(entry.name || '').toLowerCase();
      const site = String(entry.site || '').toLowerCase();
      return name === needle || site === needle;
    });
    if (direct) return direct;
  }

  return typeof SOURCE_LIST_HELPERS.resolveSourceFromCreativeName === 'function'
    ? SOURCE_LIST_HELPERS.resolveSourceFromCreativeName(entries, contextText)
    : null;
}

async function resolveMatchedSourceForTab(tab, preloaded = null) {
  const { sourceListUrl, siteOverride } = preloaded?.config || await readConfig();
  const entries = preloaded?.entries || await loadSourceEntries(sourceListUrl);
  if (!entries.length) {
    return null;
  }

  let pageText = tab?.title || '';
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => String((document.body ? document.body.innerText : '') || document.title || '').slice(0, 5000)
    });
    pageText = [tab?.title, results?.[0]?.result].filter(Boolean).join(' ');
  } catch {
    // Keep just the tab title if we can't read the page (e.g. chrome:// tabs).
  }

  const matched = matchEntryForContext(entries, pageText, siteOverride);
  return matched ? { site: matched.site || matched.name, json_url: matched.json_url } : null;
}

// ---------------------------------------------------------------------------
// File handling for the macro-upload branch
// ---------------------------------------------------------------------------

async function downloadMatchedJsonAsFile(url) {
  const response = await fetch(url, { cache: 'no-store', credentials: 'include' });
  if (!response.ok) {
    throw new Error(`Unable to download the matched JSON file (${response.status})`);
  }
  const blob = await response.blob();
  return new File([blob], 'macro-1.json', { type: blob.type || 'application/json', lastModified: Date.now() });
}

async function fileToTransferablePayload(file) {
  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return {
    fileBase64: btoa(binary),
    fileType: file.type || 'application/json',
    fileName: file.name || 'macro 1'
  };
}

// ---------------------------------------------------------------------------
// Macro-upload race fix.
//
// GAM's macro-upload widget renders its <file-detail-panel> optimistically -
// straight from the raw File object, with no network round trip - so it
// "settles" (see waitForUploadToSettle in gam-helpers.js) well before the
// call that actually registers the upload server-side
// (AssetService.createAsset) has finished. Clicking "Save and preview"
// right after the DOM settles can race ahead of that real upload, and GAM's
// own save validation then sees the macro field as still empty.
//
// Content scripts run in an isolated JS world and do not see the page's
// real fetch/XMLHttpRequest (Angular's app code runs in the MAIN world with
// its own copies of those built-ins), so the DOM can't tell us this either
// way. The only reliable signal is the network call itself. This installs a
// small sniffer directly in the page's MAIN world - BEFORE the upload is
// triggered, since createAsset can start and finish within milliseconds of
// the 'change' event - and afterward polls it for that specific call to
// complete.
//
// This only applies to the macro/macro-placeholder upload path. The
// custom-creative fetch() path never uploads a file, so running this there
// would just time out for nothing - see the mode guard in applySmartUpdate
// below.
// ---------------------------------------------------------------------------

// Runs inside the page's own MAIN world via chrome.scripting.executeScript.
// Must be fully self-contained (no references to outer closure variables) -
// only its own body is sent to the page.
function lagidiskonInstallAssetSniffer() {
  const STARTED_ATTR = 'data-lagidiskon-asset-started';
  const PENDING_ATTR = 'data-lagidiskon-asset-pending';
  const root = document.documentElement;

  if (!window.__lagidiskonAssetSnifferInstalled) {
    window.__lagidiskonAssetSnifferInstalled = true;
    window.__lagidiskonAssetCounters = { started: 0, pending: 0 };

    const counters = window.__lagidiskonAssetCounters;
    const markState = () => {
      root.setAttribute(STARTED_ATTR, String(counters.started));
      root.setAttribute(PENDING_ATTR, String(counters.pending));
    };
    markState();

    // Matches GAM's AssetService.createAsset RPC specifically - the call
    // that actually registers an uploaded macro file - not just any URL
    // that happens to contain "createAsset" somewhere in its query string.
    const isCreateAssetUrl = (url) =>
      typeof url === 'string' && /\/AssetService\?[^#]*\bmethodName=createAsset\b/.test(url);

    const OrigXHR = window.XMLHttpRequest;
    const origOpen = OrigXHR.prototype.open;
    const origSend = OrigXHR.prototype.send;

    OrigXHR.prototype.open = function (method, url, ...rest) {
      this.__lagidiskonIsCreateAsset = isCreateAssetUrl(url);
      return origOpen.call(this, method, url, ...rest);
    };

    OrigXHR.prototype.send = function (...args) {
      if (this.__lagidiskonIsCreateAsset) {
        counters.started += 1;
        counters.pending += 1;
        markState();
        this.addEventListener('loadend', () => {
          counters.pending = Math.max(0, counters.pending - 1);
          markState();
        }, { once: true });
      }
      return origSend.apply(this, args);
    };

    // GAM's own calls appear to be XHR-based (see the sniffer trace), but
    // fetch() is patched too as a harmless safety net in case that ever
    // changes.
    const origFetch = window.fetch;
    if (typeof origFetch === 'function') {
      window.fetch = function (input, init) {
        const url = typeof input === 'string' ? input : (input && input.url);
        if (isCreateAssetUrl(url)) {
          counters.started += 1;
          counters.pending += 1;
          markState();
          return origFetch.call(this, input, init).finally(() => {
            counters.pending = Math.max(0, counters.pending - 1);
            markState();
          });
        }
        return origFetch.call(this, input, init);
      };
    }
  }

  const counters = window.__lagidiskonAssetCounters;
  return { started: counters.started, pending: counters.pending };
}

// Also runs in the page's MAIN world (read-only) - kept separate from the
// installer above so repeated polling doesn't re-check the "already
// installed" guard on every call.
function lagidiskonReadAssetSnifferState() {
  const root = document.documentElement;
  return {
    started: Number(root.getAttribute('data-lagidiskon-asset-started') || '0'),
    pending: Number(root.getAttribute('data-lagidiskon-asset-pending') || '0')
  };
}

// Installs (idempotent) the sniffer and returns its current counters, to be
// used as the "baseline" the caller waits to move past. Never throws - if
// MAIN-world injection isn't available (older Chrome, a restricted page,
// etc.) this just returns a zero baseline and waitForAssetUploadSettle below
// will harmlessly time out, leaving behavior exactly as it was before this
// fix.
async function installAssetUploadSniffer(tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: lagidiskonInstallAssetSniffer
    });
    return results?.[0]?.result || { started: 0, pending: 0 };
  } catch {
    return { started: 0, pending: 0 };
  }
}

async function readAssetUploadSnifferState(tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: lagidiskonReadAssetSnifferState
    });
    return results?.[0]?.result || { started: 0, pending: 0 };
  } catch {
    return { started: 0, pending: 0 };
  }
}

// Waits for a createAsset call that started AFTER baselineStarted to also
// finish (pending back down to 0) - not just for pending to be 0, which
// would also be (wrongly) true before the call has even started yet.
// Best-effort/non-throwing by design: a timeout here just means Save
// proceeds exactly as it did before this fix, rather than introducing a new
// way for the whole run to fail.
async function waitForAssetUploadSettle(tabId, baselineStarted, { timeoutMs = 15000, pollMs = 150 } = {}) {
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    const state = await readAssetUploadSnifferState(tabId);
    if (state.started > baselineStarted && state.pending === 0) {
      return { ok: true, ...state };
    }
    await new Promise((resolve) => setTimeout(resolve, pollMs));
  }

  return { ok: false, reason: 'Timed out waiting for the macro upload network call to finish.' };
}

// ---------------------------------------------------------------------------
// The smart apply flow: custom creative -> replace fetch() URL in CodeMirror.
// Any other (standard/macro) template -> auto remove + upload the file.
// ---------------------------------------------------------------------------

async function applySmartUpdate(tab, matched, { manualFile = null } = {}) {
  if (!matched && !manualFile) {
    return { ok: false, reason: 'No matched JSON URL was found for this tab.' };
  }

  let isMacroPlaceholderBranch = false;

  if (!manualFile) {
    const customResult = await invokeGAMTabAction(tab.id, 'UPDATE_CUSTOM_CREATIVE_FETCH_URL', { value: matched.json_url });

    if (customResult?.ok) {
      return { ok: true, mode: 'custom', detail: 'fetch() URL replaced inside the CodeMirror editor.' };
    }

    if (customResult?.isMacroPlaceholder) {
      // The fetch(...) call already references a GAM macro placeholder.
      // String-replacing it with a literal URL would silently break GAM's
      // own macro substitution, so don't touch the code editor at all -
      // fall through to the macro-file replacement below instead.
      isMacroPlaceholderBranch = true;
    } else if (!customResult?.reason || !/not a custom creative/i.test(customResult.reason)) {
      // Only fall through to the macro-upload flow when this genuinely isn't
      // a custom creative. Any other failure (e.g. no fetch() call present)
      // is reported directly rather than silently trying to upload a file too.
      return { ok: false, reason: customResult?.reason || 'Custom creative update failed.' };
    }
  }

  let file;
  try {
    file = manualFile || await downloadMatchedJsonAsFile(matched.json_url);
  } catch (error) {
    return { ok: false, reason: error.message || 'Could not prepare the macro file.' };
  }

  // Install the createAsset network sniffer BEFORE triggering the upload -
  // it has to already be watching when the 'change' event fires, since the
  // real registration call can start and finish within milliseconds. See
  // the "Macro-upload race fix" block above for why this - and not the DOM
  // - is the fix.
  const assetSnifferBaseline = await installAssetUploadSniffer(tab.id);

  // Find and replace the macro slot by what it currently holds (a .json
  // file's rendered subtitle), not by a name/number - macro labels aren't a
  // reliable way to identify the right slot. This writes the new file
  // directly and does not require a separate "remove" step first.
  const transferable = await fileToTransferablePayload(file);
  const uploadResult = await invokeGAMTabAction(tab.id, 'UPLOAD_JSON_MACRO_FILE', {
    fileName: file.name || 'macro.json',
    fileBase64: transferable.fileBase64,
    fileType: transferable.fileType
  });

  if (uploadResult?.ok) {
    // Wait for the actual AssetService.createAsset call to finish, not just
    // for the DOM's optimistic <file-detail-panel> re-render (which
    // gam-helpers.js's waitForUploadToSettle already waited for inside
    // UPLOAD_JSON_MACRO_FILE above, but that alone isn't enough - see the
    // block comment above this function).
    await waitForAssetUploadSettle(tab.id, assetSnifferBaseline.started);

    const sameNameReplace = uploadResult.previousFile && uploadResult.previousFile === uploadResult.fileName;
    const detail = sameNameReplace
      ? `Replaced ${uploadResult.fileName} with an updated copy (same filename).`
      : `Replaced ${uploadResult.previousFile || 'the existing macro file'} with ${uploadResult.fileName}.`;

    return {
      ok: true,
      mode: isMacroPlaceholderBranch ? 'macro-placeholder' : 'macro',
      detail
    };
  }

  return { ok: false, reason: uploadResult?.reason || 'The macro file upload did not complete.' };
}

// ---------------------------------------------------------------------------
// UI actions - simplified interface. The underlying calls (readConfig,
// resolveMatchedSourceForTab, loadSourceEntries, applySmartUpdate) are the
// exact same calls/sequencing as before; only how progress is reported
// changed (log lines + a progress ring instead of a single status line).
// ---------------------------------------------------------------------------

function isGamTabUrl(url) {
  return typeof BATCH_HELPERS.isGAMTabUrl === 'function' ? BATCH_HELPERS.isGAMTabUrl(url) : false;
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

async function getOpenGamTabs() {
  const tabs = await chrome.tabs.query({});
  return (tabs || []).filter((t) => t && t.id && isGamTabUrl(t.url));
}

// Re-evaluates whether the currently-selected mode has a ready target, and
// enables/disables Proceed accordingly. Runs on load, on mode change, and on
// tab load-state changes (see chrome.tabs.onUpdated below) so the button
// re-enables itself the moment a loading tab finishes, with no manual
// refresh needed.
async function checkReadiness() {
  if (isProcessing) return; // don't fight the in-progress run's own UI state

  setReadiness('Checking…', 'checking');

  if (modeAllTabsInput.checked) {
    const gamTabs = await getOpenGamTabs();
    if (!gamTabs.length) {
      readyState = { ok: false, tabs: [] };
      setReadiness('No GAM tabs open', 'not-ready');
    } else {
      const loading = gamTabs.filter((t) => t.status === 'loading');
      readyState = { ok: loading.length === 0, tabs: gamTabs };
      setReadiness(
        loading.length === 0 ? `${gamTabs.length} tab(s) ready` : `${loading.length}/${gamTabs.length} loading`,
        loading.length === 0 ? 'ready' : 'loading'
      );
    }
  } else {
    const tab = await getActiveTab();
    if (!tab?.id || !isGamTabUrl(tab.url)) {
      readyState = { ok: false, tabs: [] };
      setReadiness('Not a GAM tab', 'not-ready');
    } else if (tab.status === 'loading') {
      readyState = { ok: false, tabs: [tab] };
      setReadiness('Tab loading…', 'loading');
    } else {
      readyState = { ok: true, tabs: [tab] };
      setReadiness('Ready', 'ready');
    }
  }

  proceedBtn.disabled = isProcessing || !readyState.ok;
}

// Checkboxes behave as a two-option, always-one-selected group.
function handleModeChange(changedInput) {
  const other = changedInput === modeAllTabsInput ? modeCurrentTabInput : modeAllTabsInput;
  other.checked = !changedInput.checked;
  if (!modeAllTabsInput.checked && !modeCurrentTabInput.checked) {
    changedInput.checked = true; // never allow both unchecked
  }
  checkReadiness();
}

async function runCurrentTab(tab) {
  const label = tab.title || tab.url || `Tab ${tab.id}`;
  setProgressIndeterminate('running');
  appendLog(`${label}: checking…`);

  try {
    const matched = await resolveMatchedSourceForTab(tab);
    if (!matched) {
      appendLog(`${label}: no matched source found.`);
      setProgress(100, 'error');
      return;
    }

    const result = await applySmartUpdate(tab, matched);
    if (result.ok) {
      appendLog(`${label}: ${result.detail || 'updated.'}`);
      setProgress(100, 'success');

      // Process reached 100% and the line item was actually changed - now
      // save it via GAM's own "Save and preview" button.
      const saveResult = await invokeGAMTabAction(tab.id, 'CLICK_SAVE_AND_PREVIEW');
      appendLog(saveResult?.ok
        ? `${label}: saved.`
        : `${label}: save failed - ${saveResult?.reason || 'unknown error'}.`);
    } else {
      appendLog(`${label}: ${result.reason || 'update failed.'}`);
      setProgress(100, 'error');
    }
  } catch (error) {
    appendLog(`${label}: ${error.message || 'unexpected error.'}`);
    setProgress(100, 'error');
  }
}

// ---------------------------------------------------------------------------
// Bulk-save background-tab fix - now delegated to background.js.
//
// Chrome pauses/throttles a lot of timer- and requestAnimationFrame-driven
// JS work in tabs that aren't the focused, active tab - and GAM's own Save
// button appears to depend on that (its Angular change-detection/validation
// state, not just the DOM node) before a click on it actually registers as
// a real save. That's why "process current tab" (always focused) never
// sees this, while bulk mode - which saves tabs sequentially while they sit
// in the background - does.
//
// The fix is to briefly focus each tab right before clicking its Save
// button. That has to run in background.js, not here: focusing another
// tab/window is exactly the kind of event that makes Chrome auto-close this
// popup, and a closed popup's JS is torn down immediately - which used to
// kill this very loop mid-run (some tabs would get no log line at all,
// looking like the run just silently stopped). See runBulkSave() in
// background.js for the actual activate-then-save logic; this just hands it
// the list of tabs to save and renders whatever progress makes it back.
// ---------------------------------------------------------------------------

async function delegateBulkSave(toSave) {
  const items = toSave.map((item) => ({ tabId: item.tabId, title: item.title }));

  // Live progress while the popup happens to stay open. If it closes
  // partway through (still possible - see the comment above), this
  // listener simply stops receiving anything; recoverLastBulkSave() below
  // covers that case on the next popup open instead.
  const progressListener = (message) => {
    if (message?.type !== 'BULK_SAVE_PROGRESS' || !message.result) return;
    const { title, ok, reason } = message.result;
    appendLog(ok ? `${title}: saved.` : `${title}: save failed - ${reason || 'unknown error'}.`);
  };
  chrome.runtime.onMessage.addListener(progressListener);

  try {
    const summary = await chrome.runtime.sendMessage({ type: 'BULK_SAVE_TABS', items });
    appendLog(`Saved ${summary?.savedCount ?? 0}/${toSave.length} tab(s).`);
  } catch (error) {
    // The popup itself closed (or never got the response) before the
    // background finished - the run continues regardless, and
    // recoverLastBulkSave() will surface its result next time the popup
    // opens.
    appendLog(`Bulk save is continuing in the background (popup lost the connection: ${error.message || 'unexpected error'}).`);
  } finally {
    chrome.runtime.onMessage.removeListener(progressListener);
  }
}

// Shows the result of a bulk save that finished after this popup had
// already closed, so a run that looked like it "went nowhere" isn't
// actually silently lost - it's sitting in chrome.storage.local, written by
// background.js's runBulkSave() right after the loop finishes.
async function recoverLastBulkSave() {
  try {
    const stored = await chrome.storage.local.get('lagidiskonLastBulkSave');
    const summary = stored.lagidiskonLastBulkSave;
    if (!summary || summary.shown) return;

    // Only surface this if it's fresh - an old run from a while back isn't
    // relevant to "what just happened", it's just stale storage.
    if (Date.now() - (summary.completedAt || 0) > 2 * 60 * 1000) return;

    appendLog('Recovered result from a bulk save that finished after the popup closed:');
    (summary.results || []).forEach((result) => {
      appendLog(result.ok
        ? `${result.title}: saved.`
        : `${result.title}: save failed - ${result.reason || 'unknown error'}.`);
    });
    appendLog(`Saved ${summary.savedCount}/${summary.total} tab(s).`);

    await chrome.storage.local.set({ lagidiskonLastBulkSave: { ...summary, shown: true } });
  } catch {
    // Best-effort - not worth surfacing a failure just to report an older one.
  }
}

async function runAllTabs(gamTabs) {
  const queue = typeof BATCH_HELPERS.buildTabQueue === 'function' ? BATCH_HELPERS.buildTabQueue(gamTabs) : [];
  if (!queue.length) {
    appendLog('No GAM tabs to process.');
    setProgress(0, 'error');
    return;
  }

  setProgress(0, 'running');
  appendLog(`Loading source list for ${queue.length} tab(s)…`);

  // Fetch and parse the source list ONCE for the whole batch, not once per
  // tab - refetching per tab is both wasteful and a real source of
  // intermittent per-tab failures if that fetch is ever slow/flaky.
  let preloaded;
  try {
    const config = await readConfig();
    const entries = await loadSourceEntries(config.sourceListUrl);
    preloaded = { config, entries };
  } catch (error) {
    appendLog(`Could not load the source list: ${error.message}`);
    setProgress(0, 'error');
    return;
  }

  let successCount = 0;

  for (let i = 0; i < queue.length; i++) {
    const item = queue[i];
    const tabRef = { id: item.tabId, title: item.title };

    try {
      const matched = await resolveMatchedSourceForTab(tabRef, preloaded);
      if (!matched) {
        item.status = 'failed';
        item.lastError = 'No matched source found for this tab.';
      } else {
        const result = await applySmartUpdate(tabRef, matched);
        item.status = result.ok ? 'success' : 'failed';
        item.mode = result.mode || '';
        item.lastError = result.ok ? '' : (result.reason || 'Update failed.');
        if (result.ok) successCount += 1;
      }
    } catch (error) {
      item.status = 'failed';
      item.lastError = error.message || 'Unexpected error.';
    }

    appendLog(item.status === 'success'
      ? `${item.title}: ${item.mode || 'updated'}`
      : `${item.title}: ${item.lastError}`);
    setProgress(((i + 1) / queue.length) * 100, 'running');
  }

  setProgress(100, successCount === queue.length ? 'success' : 'error');
  appendLog(`Done: ${successCount}/${queue.length} tab(s) updated.`);

  // Process just reached 100% - now save the line item in each tab that was
  // actually changed (skip tabs that failed; nothing to save there).
  const toSave = queue.filter((item) => item.status === 'success');
  if (toSave.length) {
    appendLog(`Saving ${toSave.length} tab(s)…`);
    await delegateBulkSave(toSave);
  }
}

async function handleProceed() {
  if (isProcessing || !readyState.ok) return;

  isProcessing = true;
  proceedBtn.disabled = true;
  clearLog();

  if (modeAllTabsInput.checked) {
    await runAllTabs(readyState.tabs);
  } else {
    await runCurrentTab(readyState.tabs[0]);
  }

  isProcessing = false;
  await checkReadiness();
}

async function hydrate() {
  setProgress(0, 'idle');
  await recoverLastBulkSave();
  await checkReadiness();
}

modeCurrentTabInput.addEventListener('change', () => handleModeChange(modeCurrentTabInput));
modeAllTabsInput.addEventListener('change', () => handleModeChange(modeAllTabsInput));
proceedBtn.addEventListener('click', handleProceed);

// Keep readiness (and the Proceed button) in sync as tabs load/close, so a
// tab that was "loading" auto-enables the button once it finishes, with no
// manual refresh needed.
if (chrome.tabs?.onUpdated) {
  chrome.tabs.onUpdated.addListener(() => checkReadiness());
}
if (chrome.tabs?.onActivated) {
  chrome.tabs.onActivated.addListener(() => checkReadiness());
}
if (chrome.tabs?.onRemoved) {
  chrome.tabs.onRemoved.addListener(() => checkReadiness());
}

hydrate();
