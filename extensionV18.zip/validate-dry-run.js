const fs = require('fs');
const path = require('path');

const root = __dirname;
const manifestPath = path.join(root, 'manifest.json');
const requiredFiles = [
  'manifest.json',
  'background.js',
  'content.js',
  'gam-helpers.js',
  'batch-helpers.js',
  'source-list.js',
  'popup.html',
  'popup.css',
  'popup.js',
  'runbook.md'
];

function assert(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
assert(manifest.manifest_version === 3, 'Manifest version must be 3');
assert(Array.isArray(manifest.content_scripts) && manifest.content_scripts.length > 0, 'Content scripts must be configured');
assert(Array.isArray(manifest.permissions) && manifest.permissions.includes('activeTab'), 'activeTab permission required');
assert(Array.isArray(manifest.permissions) && manifest.permissions.includes('storage'), 'storage permission required');

requiredFiles.forEach((file) => {
  assert(fs.existsSync(path.join(root, file)), `Required file missing: ${file}`);
});

console.log('Dry run validation passed: manifest, required files, and runtime setup are present.');
