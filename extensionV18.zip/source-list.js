(function () {
  function dedupeUrls(urls) {
    return Array.from(new Set((urls || []).map((value) => String(value).trim()).filter(Boolean)));
  }

  function isHttpUrl(value) {
    try {
      const url = new URL(value);
      return ['http:', 'https:'].includes(url.protocol);
    } catch {
      return false;
    }
  }

  function normalizeGoogleDriveUrl(value) {
    const trimmed = String(value || '').trim();
    if (!trimmed) {
      return '';
    }

    try {
      const url = new URL(trimmed);
      const driveId = url.searchParams.get('id') || url.pathname.match(/\/file\/d\/([^/]+)/)?.[1];

      if (url.hostname === 'drive.google.com' && driveId) {
        return `https://drive.google.com/uc?export=download&id=${driveId}`;
      }

      return trimmed;
    } catch {
      return trimmed;
    }
  }

  function extractUrlsFromPayload(payload) {
    const urls = [];

    const addUrl = (candidate) => {
      if (typeof candidate !== 'string') {
        return;
      }

      const normalized = normalizeGoogleDriveUrl(candidate.trim());
      if (normalized && isHttpUrl(normalized)) {
        urls.push(normalized);
      }
    };

    const walk = (node) => {
      if (!node) {
        return;
      }

      if (typeof node === 'string') {
        addUrl(node);
        return;
      }

      if (Array.isArray(node)) {
        node.forEach((item) => walk(item));
        return;
      }

      if (typeof node === 'object') {
        const explicitKeys = ['sources', 'urls', 'data', 'items', 'results', 'list', 'entries', 'records', 'links', 'files', 'creativeUrls'];

        for (const key of explicitKeys) {
          if (key in node) {
            walk(node[key]);
          }
        }

        if (typeof node.url === 'string') {
          addUrl(node.url);
        }
        if (typeof node.value === 'string') {
          addUrl(node.value);
        }
        if (typeof node.href === 'string') {
          addUrl(node.href);
        }

        for (const value of Object.values(node)) {
          if (value && typeof value !== 'function') {
            walk(value);
          }
        }
      }
    };

    walk(payload);
    return dedupeUrls(urls);
  }

  function extractSourceEntriesFromPayload(payload) {
    const entries = [];
    const seen = new Set();

    const addEntry = (node) => {
      if (!node || typeof node !== 'object' || Array.isArray(node)) {
        return;
      }

      const jsonUrl = typeof node.json_url === 'string'
        ? node.json_url
        : typeof node.url === 'string'
          ? node.url
          : typeof node.value === 'string'
            ? node.value
            : '';

      const rawName = typeof node.name === 'string' ? node.name : typeof node.site === 'string' ? node.site : '';
      if (!jsonUrl || !rawName) {
        return;
      }

      const normalizedUrl = normalizeGoogleDriveUrl(jsonUrl.trim());
      if (!normalizedUrl || !isHttpUrl(normalizedUrl)) {
        return;
      }

      const entry = {
        name: rawName.trim(),
        site: (node.site || rawName || '').trim(),
        json_url: normalizedUrl
      };
      const key = `${entry.name}|${entry.json_url}`;
      if (seen.has(key)) {
        return;
      }
      seen.add(key);
      entries.push(entry);
    };

    const walk = (node) => {
      if (!node) return;
      if (Array.isArray(node)) {
        node.forEach(walk);
        return;
      }
      if (typeof node === 'object') {
        if (Object.prototype.hasOwnProperty.call(node, 'json_url') || Object.prototype.hasOwnProperty.call(node, 'name') || Object.prototype.hasOwnProperty.call(node, 'site')) {
          addEntry(node);
        }
        for (const value of Object.values(node)) {
          if (value && typeof value !== 'function') {
            walk(value);
          }
        }
      }
    };

    walk(payload);
    return entries;
  }

  async function fetchSourceListUrls(rawValue) {
    const candidate = normalizeGoogleDriveUrl(rawValue);
    if (!candidate || !isHttpUrl(candidate)) {
      return [];
    }

    const response = await fetch(candidate, { cache: 'no-store', credentials: 'include' });
    if (!response.ok) {
      throw new Error(`Unable to fetch source list: ${response.status}`);
    }

    let payload;

    try {
      payload = await response.json();
    } catch {
      const textBody = await response.text();
      try {
        payload = JSON.parse(textBody);
      } catch {
        const lines = textBody
          .split(/\r?\n|,/) 
          .map((line) => line.trim())
          .filter(Boolean);
        return dedupeUrls(lines.filter((item) => isHttpUrl(normalizeGoogleDriveUrl(item))));
      }
    }

    const urls = extractUrlsFromPayload(payload);
    return dedupeUrls(urls);
  }

  // ---------------------------------------------------------------------
  // Google Sheets source support.
  //
  // Fetches the sheet as CSV (Sheets' own /export?format=csv endpoint -
  // works for "Anyone with the link can view" sheets with no auth dance)
  // and reads ONLY two columns by header name: "site" and "url" (also
  // accepts "name" for site and "json_url" for url, for a header row that
  // uses the same wording as the old JSON format). Any other columns in the
  // sheet are ignored entirely, as requested.
  // ---------------------------------------------------------------------

  function isGoogleSheetsUrl(value) {
    try {
      const url = new URL(String(value || '').trim());
      return url.hostname === 'docs.google.com' && url.pathname.includes('/spreadsheets/');
    } catch {
      return false;
    }
  }

  function extractSheetIdAndGid(value) {
    try {
      const url = new URL(String(value || '').trim());
      const id = url.pathname.match(/\/spreadsheets\/d\/([^/]+)/)?.[1] || '';
      const gid = url.searchParams.get('gid') || url.hash.match(/gid=(\d+)/)?.[1] || '0';
      return { id, gid };
    } catch {
      return { id: '', gid: '0' };
    }
  }

  // A Sheets "edit" URL (…/edit?usp=sharing) can't be fetched directly as
  // data - this converts it to the CSV export endpoint for the same sheet
  // tab (gid).
  function normalizeGoogleSheetsCsvUrl(value) {
    const { id, gid } = extractSheetIdAndGid(value);
    return id ? `https://docs.google.com/spreadsheets/d/${id}/export?format=csv&gid=${gid}` : '';
  }

  // Minimal RFC-4180-ish CSV parser: handles quoted fields, escaped quotes
  // ("") inside a quoted field, commas/newlines inside quotes, and CRLF or
  // LF line endings. No external dependency needed for two plain columns.
  function parseCsv(text) {
    const rows = [];
    let row = [];
    let field = '';
    let inQuotes = false;
    const source = String(text || '');

    for (let i = 0; i < source.length; i++) {
      const char = source[i];

      if (inQuotes) {
        if (char === '"') {
          if (source[i + 1] === '"') {
            field += '"';
            i += 1;
          } else {
            inQuotes = false;
          }
        } else {
          field += char;
        }
        continue;
      }

      if (char === '"') {
        inQuotes = true;
      } else if (char === ',') {
        row.push(field);
        field = '';
      } else if (char === '\n') {
        row.push(field);
        rows.push(row);
        row = [];
        field = '';
      } else if (char === '\r') {
        // ignore - \n (handled above) always follows in CRLF line endings
      } else {
        field += char;
      }
    }

    if (field.length > 0 || row.length > 0) {
      row.push(field);
      rows.push(row);
    }

    return rows.filter((cells) => cells.some((cell) => String(cell || '').trim()));
  }

  // Reads ONLY the "site" and "url" columns (by header name, case-
  // insensitive) - every other column in the sheet is ignored.
  function extractSourceEntriesFromCsv(csvText) {
    const rows = parseCsv(csvText);
    if (rows.length < 2) {
      return [];
    }

    const header = rows[0].map((cell) => String(cell || '').trim().toLowerCase());
    const siteIdx = header.findIndex((cell) => cell === 'site' || cell === 'name');
    const urlIdx = header.findIndex((cell) => cell === 'url' || cell === 'json_url');

    if (siteIdx === -1 || urlIdx === -1) {
      return [];
    }

    const entries = [];
    const seen = new Set();

    for (let i = 1; i < rows.length; i++) {
      const site = String(rows[i][siteIdx] || '').trim();
      const rawUrl = String(rows[i][urlIdx] || '').trim();
      if (!site || !rawUrl || !isHttpUrl(rawUrl)) {
        continue;
      }

      const key = `${site}|${rawUrl}`;
      if (seen.has(key)) {
        continue;
      }
      seen.add(key);

      entries.push({ name: site, site, json_url: rawUrl });
    }

    return entries;
  }

  // Single entry point popup.js calls to load source entries - detects a
  // Google Sheets URL and reads it as site/url CSV; otherwise falls back to
  // the original Drive/JSON-file behavior (extractSourceEntriesFromPayload)
  // unchanged, so an existing Drive JSON source list still works.
  async function loadSourceEntriesFromUrl(rawValue) {
    const trimmed = String(rawValue || '').trim();
    if (!trimmed) {
      return [];
    }

    if (isGoogleSheetsUrl(trimmed)) {
      const csvUrl = normalizeGoogleSheetsCsvUrl(trimmed);
      if (!csvUrl) {
        throw new Error('Could not resolve a spreadsheet ID from the source URL.');
      }

      const response = await fetch(csvUrl, { cache: 'no-store', credentials: 'include' });
      if (!response.ok) {
        throw new Error(`Unable to fetch the source sheet (${response.status})`);
      }

      const csvText = await response.text();
      return extractSourceEntriesFromCsv(csvText);
    }

    const normalized = normalizeGoogleDriveUrl(trimmed);
    const response = await fetch(normalized, { cache: 'no-store', credentials: 'include' });
    if (!response.ok) {
      throw new Error(`Unable to fetch the source list (${response.status})`);
    }

    const payload = await response.json();
    return extractSourceEntriesFromPayload(payload);
  }

  function normalizeSiteAlias(value) {
    return String(value || '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '')
      .trim();
  }

  function resolveSiteFromCreativeName(creativeName, siteEntries = []) {
    const rawName = String(creativeName || '').trim();
    if (!rawName) {
      return null;
    }

    const lookupTarget = normalizeSiteAlias(rawName);
    for (const entry of siteEntries || []) {
      const candidateSite = normalizeSiteAlias(entry?.site || entry?.name || '');
      const candidateAlias = normalizeSiteAlias(entry?.name || entry?.site || '');
      const aliases = [candidateSite, candidateAlias];

      if (aliases.some((alias) => alias && lookupTarget.includes(alias))) {
        return {
          site: entry?.site || entry?.name || '',
          name: entry?.name || entry?.site || '',
          raw: entry
        };
      }

      if (lookupTarget.includes(candidateSite) || lookupTarget.includes(candidateAlias)) {
        return {
          site: entry?.site || entry?.name || '',
          name: entry?.name || entry?.site || '',
          raw: entry
        };
      }
    }

    return null;
  }

  function resolveSourceFromCreativeName(sourceEntries = [], creativeName) {
    const matched = resolveSiteFromCreativeName(creativeName, sourceEntries);
    if (!matched) {
      return null;
    }

    const direct = sourceEntries.find((entry) => {
      const entrySite = normalizeSiteAlias(entry?.site || entry?.name || '');
      const entryName = normalizeSiteAlias(entry?.name || entry?.site || '');
      return entrySite === normalizeSiteAlias(matched.site) || entryName === normalizeSiteAlias(matched.name);
    });

    return direct || matched.raw || null;
  }

  async function expandSourceEntries(entries) {
    const expanded = [];

    for (const entry of entries || []) {
      const rawValue = typeof entry === 'string' ? entry : entry?.value || entry?.url || entry?.source || '';
      const candidate = String(rawValue || '').trim();

      if (!candidate) {
        continue;
      }

      try {
        const discovered = await fetchSourceListUrls(candidate);
        if (discovered.length > 0) {
          discovered.forEach((url, index) => {
            expanded.push({
              id: `${entry?.id || 'source'}-${index + 1}`,
              site: entry?.site || `Source ${index + 1}`,
              value: url
            });
          });
          continue;
        }
      } catch {
        // Fall back to the original value if the URL is not a list payload.
      }

      expanded.push({
        id: entry?.id || `source-${expanded.length + 1}`,
        site: entry?.site || `Source ${expanded.length + 1}`,
        value: normalizeGoogleDriveUrl(candidate)
      });
    }

    return expanded;
  }

  const api = {
    normalizeGoogleDriveUrl,
    extractUrlsFromPayload,
    extractSourceEntriesFromPayload,
    fetchSourceListUrls,
    expandSourceEntries,
    isHttpUrl,
    normalizeSiteAlias,
    resolveSiteFromCreativeName,
    resolveSourceFromCreativeName,
    isGoogleSheetsUrl,
    extractSheetIdAndGid,
    normalizeGoogleSheetsCsvUrl,
    parseCsv,
    extractSourceEntriesFromCsv,
    loadSourceEntriesFromUrl
  };

  globalThis.SOURCE_LIST_HELPERS = api;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }
})();
