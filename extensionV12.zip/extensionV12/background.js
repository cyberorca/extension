const DEFAULT_DRIVE_SOURCE_URL = 'https://drive.google.com/file/d/1je54X0abTr10oA-0u0jx8Cnpxg8adBLD/view?usp=sharing';

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    lagidiskonConfig: {
      sources: Array.from({ length: 6 }, (_, i) => ({
        id: `source${i + 1}`,
        value: i === 0 ? DEFAULT_DRIVE_SOURCE_URL : ''
      }))
    }
  });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'READ_ACTIVE_TAB') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const [tab] = tabs;
      sendResponse({
        ok: true,
        url: tab?.url ?? null,
        title: tab?.title ?? null
      });
    });
    return true;
  }

  if (message?.type === 'VALIDATE_CONFIG') {
    const sources = Array.isArray(message.sources) ? message.sources : [];
    const issues = sources
      .filter((value) => typeof value === 'string' && value.trim())
      .map((value) => value.trim())
      .filter((value) => {
        try {
          const url = new URL(value);
          return ['http:', 'https:'].includes(url.protocol);
        } catch {
          return true;
        }
      });

    sendResponse({
      ok: issues.length === 0,
      invalidCount: issues.length
    });
    return true;
  }

  return false;
});
