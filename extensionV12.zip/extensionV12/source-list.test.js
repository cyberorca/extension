const test = require('node:test');
const assert = require('node:assert/strict');
const {
  normalizeGoogleDriveUrl,
  extractUrlsFromPayload,
  extractSourceEntriesFromPayload,
  expandSourceEntries,
  resolveSiteFromCreativeName,
  resolveSourceFromCreativeName
} = require('./source-list.js');

test('normalizeGoogleDriveUrl converts a Drive view URL into a downloadable file URL', () => {
  const value = 'https://drive.google.com/file/d/1je54X0abTr10oA-0u0jx8Cnpxg8adBLD/view';
  assert.equal(
    normalizeGoogleDriveUrl(value),
    'https://drive.google.com/uc?export=download&id=1je54X0abTr10oA-0u0jx8Cnpxg8adBLD'
  );
});

test('extractUrlsFromPayload flattens JSON arrays and nested objects into source URL candidates', () => {
  const payload = {
    sources: [
      'https://cdn.example.com/a.json',
      { url: 'https://cdn.example.com/b.json' },
      { item: { value: 'https://cdn.example.com/c.json' } }
    ]
  };

  assert.deepEqual(extractUrlsFromPayload(payload), [
    'https://cdn.example.com/a.json',
    'https://cdn.example.com/b.json',
    'https://cdn.example.com/c.json'
  ]);
});

test('expandSourceEntries resolves list-driven JSON URLs into concrete source entries', async () => {
  const originalFetch = globalThis.fetch;

  globalThis.fetch = async () => ({
    ok: true,
    json: async () => ({
      sources: [
        'https://cdn.example.com/a.json',
        'https://cdn.example.com/b.json'
      ]
    })
  });

  try {
    const result = await expandSourceEntries([
      { id: 'source1', site: 'Site A', value: 'https://drive.google.com/file/d/1je54X0abTr10oA-0u0jx8Cnpxg8adBLD/view' }
    ]);

    assert.deepEqual(result.map((item) => item.value), [
      'https://cdn.example.com/a.json',
      'https://cdn.example.com/b.json'
    ]);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('extractSourceEntriesFromPayload reads name/json_url objects from a list payload', () => {
  const payload = [
    { name: 'kapanlagi.com', json_url: 'https://example.com/site1/data.json' },
    { name: 'bola.net', json_url: 'https://example.com/site2/data.json' },
    { name: 'liputan6.com', json_url: 'https://example.com/site3/data.json' }
  ];

  assert.deepEqual(extractSourceEntriesFromPayload(payload), [
    { name: 'kapanlagi.com', site: 'kapanlagi.com', json_url: 'https://example.com/site1/data.json' },
    { name: 'bola.net', site: 'bola.net', json_url: 'https://example.com/site2/data.json' },
    { name: 'liputan6.com', site: 'liputan6.com', json_url: 'https://example.com/site3/data.json' }
  ]);
});

test('resolveSiteFromCreativeName picks the matching site alias from the creative title', () => {
  const creativeName = '# [OMP] | [LagiDiskon ] [Desktop Masthead] | Affiliate BOLANET';
  const matched = resolveSiteFromCreativeName(creativeName, [
    { site: 'liputan6', name: 'Liputan6' },
    { site: 'bola.net', name: 'Bola.net' },
    { site: 'fimela', name: 'Fimela' }
  ]);

  assert.equal(matched.site, 'bola.net');
  assert.equal(matched.name, 'Bola.net');
});

test('resolveSourceFromCreativeName returns the correct json_url for the matched site alias', () => {
  const creativeName = '# [OMP] | [LagiDiskon ] [Desktop Masthead] | Affiliate BOLANET';
  const payload = [
    { name: 'Liputan6', site: 'liputan6', json_url: 'https://cdn.example.com/liputan6.json' },
    { name: 'Bola.net', site: 'bola.net', json_url: 'https://cdn.example.com/bola.net.json' },
    { name: 'Fimela', site: 'fimela', json_url: 'https://cdn.example.com/fimela.json' }
  ];

  const match = resolveSourceFromCreativeName(payload, creativeName);
  assert.equal(match.json_url, 'https://cdn.example.com/bola.net.json');
  assert.equal(match.site, 'bola.net');
});
