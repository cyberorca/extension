const helpers = globalThis.GAM_HELPERS || window.GAM_HELPERS;

function resolveWriteTarget() {
  if (!helpers || typeof helpers.resolveWriteTarget !== 'function') {
    return null;
  }

  return helpers.resolveWriteTarget(document);
}

function getPageGuardState(target) {
  const isStale = !(helpers && typeof helpers.isLikelyGAMPage === 'function')
    ? false
    : !helpers.isLikelyGAMPage(window.location.href);

  return helpers && typeof helpers.validateTargetState === 'function'
    ? helpers.validateTargetState({ pageIsStale: isStale, target })
    : { ok: !!target, reason: target ? 'Target is ready for update.' : 'No editable JSON field found in the current page.' };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'GET_CREATIVE_TYPE') {
    const type = helpers && typeof helpers.getCreativeTypeLabel === 'function'
      ? helpers.getCreativeTypeLabel(document)
      : '';
    sendResponse({ ok: true, creativeType: type });
    return true;
  }

  if (message?.type === 'REMOVE_MACRO_BY_NAME') {
    const result = helpers && typeof helpers.removeMacroByName === 'function'
      ? helpers.removeMacroByName(document, message.name || 'macro 1')
      : { ok: false, reason: 'Macro removal helper is not available.' };
    sendResponse(result);
    return true;
  }

  if (message?.type === 'UPLOAD_MACRO_FILE') {
    // Accept either a transferable { fileBase64, fileType } payload (preferred -
    // survives message passing reliably) or a legacy raw File/string.
    const fileArg = message.fileBase64
      ? { base64: message.fileBase64, type: message.fileType }
      : (message.file || message.content || message.value || '');

    const result = helpers && typeof helpers.uploadMacroFile === 'function'
      ? helpers.uploadMacroFile(document, message.fileName || 'macro 1', fileArg)
      : { ok: false, reason: 'Macro upload helper is not available.' };
    sendResponse(result);
    return true;
  }

  if (message?.type === 'UPLOAD_JSON_MACRO_FILE') {
    // Finds the macro slot by what it currently holds (a .json file's
    // rendered title/subtitle), or - if this field has never had a file at
    // all yet - by its own label ("Json File"), then uploads directly.
    const fileArg = message.fileBase64
      ? { base64: message.fileBase64, type: message.fileType }
      : (message.file || message.content || message.value || '');
    const fileName = message.fileName || 'macro.json';
    const labelText = message.labelText || 'Json File';

    (async () => {
      if (!helpers || typeof helpers.uploadJsonMacroFile !== 'function') {
        sendResponse({ ok: false, reason: 'JSON macro upload helper is not available.' });
        return;
      }

      let result = await helpers.uploadJsonMacroFile(document, fileName, fileArg, { labelText });

      // The upload widget can be inserted into the DOM asynchronously
      // (dialogs opening, *ngIf-gated sections). Only wait-and-retry when
      // the field genuinely isn't there yet - i.e. neither an existing
      // .json macro slot nor a matching labeled field was found - not for
      // any other kind of failure.
      const notYetRendered = !result.ok && /No upload input was found for the/i.test(result.reason || '');

      if (notYetRendered && typeof helpers.waitForUploadInputForLabel === 'function') {
        try {
          await helpers.waitForUploadInputForLabel(document, labelText, { timeoutMs: 5000 });
          result = helpers.uploadJsonMacroFile(document, fileName, fileArg, { labelText });
        } catch (waitError) {
          result = { ok: false, reason: waitError.message || 'The upload field never rendered in time.' };
        }
      }

      sendResponse(result);
    })();

    return true; // keep the message channel open for the async sendResponse above
  }

  if (message?.type === 'UPDATE_CUSTOM_CREATIVE_FETCH_URL') {
    const result = helpers && typeof helpers.updateCustomCreativeFetchUrl === 'function'
      ? helpers.updateCustomCreativeFetchUrl(document, message.value || message.url || '')
      : { ok: false, reason: 'Custom creative fetch helper is not available.' };
    sendResponse(result);
    return true;
  }

  if (message?.type !== 'WRITE_JSON_FIELD') {
    return false;
  }

  const { value } = message;
  const target = resolveWriteTarget();
  const guard = getPageGuardState(target);

  if (!guard.ok) {
    sendResponse({ ok: false, reason: guard.reason });
    return true;
  }

  try {
    const previousValue = target.value ?? target.textContent ?? '';
    if (typeof target.value === 'string' || typeof target.value === 'number') {
      target.value = value;
    } else if (typeof target.textContent === 'string') {
      target.textContent = value;
    } else {
      target.setAttribute('value', value);
    }

    const updated = String(target.value ?? target.textContent ?? target.getAttribute('value') ?? '').trim();
    sendResponse({
      ok: updated === String(value).trim(),
      previousValue,
      updatedValue: updated,
      fieldLabel: target.name || target.id || target.getAttribute('aria-label') || 'unknown'
    });
    return true;
  } catch (error) {
    sendResponse({ ok: false, reason: error.message || 'Field update failed.' });
    return true;
  }
});
