(function (global) {
  const DEFAULT_SELECTOR_HINTS = [
    "input[name*='json' i]",
    "input[name*='url' i]",
    "textarea[name*='json' i]",
    "textarea[name*='url' i]",
    "input[id*='json' i]",
    "input[id*='url' i]",
    "textarea[id*='json' i]",
    "textarea[id*='url' i]",
    "[aria-label*='json' i]",
    "[aria-label*='url' i]",
    "[placeholder*='json' i]",
    "[placeholder*='url' i]"
  ];

  function getCandidateFields(doc = global.document) {
    if (!doc || typeof doc.querySelectorAll !== 'function') {
      return [];
    }

    const fields = new Set();
    DEFAULT_SELECTOR_HINTS.forEach((selector) => {
      doc.querySelectorAll(selector).forEach((field) => fields.add(field));
    });
    return [...fields];
  }

  function scoreField(field) {
    if (!field || typeof field !== 'object') return 0;

    const text = [
      field.name || '',
      field.id || '',
      field.getAttribute?.('aria-label') || '',
      field.getAttribute?.('placeholder') || '',
      field.value || ''
    ].join(' ').toLowerCase();

    let score = 0;
    if (text.includes('json')) score += 4;
    if (text.includes('url')) score += 3;
    if (text.includes('creative')) score += 2;
    if (field.tagName === 'INPUT') score += 1;
    if (field.tagName === 'TEXTAREA') score += 2;
    if (field.readOnly) score -= 5;
    return score;
  }

  function resolveWriteTarget(doc = global.document) {
    const candidates = getCandidateFields(doc)
      .filter((field) => field && !field.disabled)
      .sort((a, b) => scoreField(b) - scoreField(a));

    return candidates[0] || null;
  }

  function isLikelyGAMPage(url = (global.location ? global.location.href : '')) {
    if (!url) return false;
    const href = String(url).toLowerCase();
    const isGAMHost = href.includes('admanager.google.com') || href.includes('google.com/dfp') || href.includes('googleadmanager');
    const isCreativeContext = href.includes('creative') || href.includes('inventory') || href.includes('order');
    return isGAMHost && (isCreativeContext || href.includes('creative') || href.includes('inventory'));
  }

  function validateTargetState({ pageIsStale = false, target = null }) {
    if (pageIsStale) {
      return { ok: false, reason: 'The current page appears stale or not on the GAM edit screen.' };
    }

    if (!target) {
      return { ok: false, reason: 'No editable JSON field found in the current page.' };
    }

    return { ok: true, reason: 'Target is ready for update.' };
  }

  function normalizeMacroName(value) {
    return String(value || '').trim().toLowerCase().replace(/\s+/g, ' ');
  }

  function getCreativeTypeLabel(doc = global.document) {
    if (!doc || typeof doc.querySelectorAll !== 'function') {
      return '';
    }

    const subheaderItems = Array.from(doc.querySelectorAll('.subheader-item'));
    for (const item of subheaderItems) {
      const text = (item.textContent || '').replace(/\s+/g, ' ').trim();
      if (/^creative type\s*:/i.test(text)) {
        return text.replace(/^creative type\s*:/i, '').trim();
      }
    }

    return '';
  }

  // Matches fetch("..."), fetch('...') or fetch(`...`) with ANY content inside
  // the quotes (including none) - not just an empty fetch("") call. This is
  // what makes replacing an *existing* URL on a second/third run work, not
  // just filling in a freshly-templated blank creative.
  //
  // The 'd' (hasIndices) flag gives match.indices[group] = [start, end], so
  // callers can locate exactly where the quoted content sits and replace
  // ONLY that substring - not the whole `fetch("...")` text - which is what
  // lets this survive arbitrary surrounding formatting.
  const FETCH_CALL_REGEX = /fetch\(\s*(['"`])([\s\S]*?)\1/d;

  // CodeMirror's getLine(i) only ever returns ONE line. A `fetch(` call that
  // GAM/Prettier has wrapped across lines - e.g.
  //   fetch(
  //     "https://old.example/data.json"
  //   )
  // - has no single line containing both `fetch(` and the quoted URL, so a
  // per-line regex scan never finds it ("No fetch(...) call was found" even
  // though one clearly exists). Joining the whole document into one string
  // before matching fixes that.
  function getEditorFullText(editor) {
    if (typeof editor.getValue === 'function') {
      return editor.getValue();
    }
    const lineCount = editor.lineCount();
    const lines = [];
    for (let i = 0; i < lineCount; i++) {
      lines.push(editor.getLine(i));
    }
    return lines.join('\n');
  }

  // Converts an absolute character offset into a document (as produced by
  // getEditorFullText, lines joined with '\n') into CodeMirror's {line, ch}
  // coordinates.
  function offsetToLineCh(fullText, offset) {
    const consumed = fullText.slice(0, offset).split('\n');
    return { line: consumed.length - 1, ch: consumed[consumed.length - 1].length };
  }

  // GAM's own macro placeholder syntax, e.g. %%FILE:MACRO2%%. When a custom
  // creative's fetch(...) call references one of these, GAM substitutes it
  // server-side with the content of an uploaded macro file at serving time -
  // it is not a literal URL at all, even though it sits inside a fetch(...)
  // call like one would be.
  const MACRO_PLACEHOLDER_REGEX = /^%%FILE:([A-Za-z0-9_]+)%%$/i;

  // Turns a placeholder's macro name (MACRO2) into the display form GAM uses
  // for the macro row/button in its own UI ("Macro 2"), so it can be matched
  // against removeMacroByName()/uploadMacroFile()'s label-based lookup.
  function macroPlaceholderToDisplayName(macroName) {
    const raw = String(macroName || '').trim();
    if (!raw) return 'Macro 1';
    const spaced = raw.replace(/([A-Za-z]+)(\d+)/, '$1 $2');
    return spaced
      .split(/\s+/)
      .filter(Boolean)
      .map((part) => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase())
      .join(' ');
  }

  function extractFetchMatch(text) {
    const match = String(text || '').match(FETCH_CALL_REGEX);
    return match ? { quote: match[1], value: match[2] } : null;
  }

  // Peeks at the current fetch(...) content across CodeMirror editors and
  // plain fallback nodes WITHOUT mutating anything - used to check whether
  // the existing value is a macro placeholder before deciding how (or
  // whether) to replace it. Scans each editor's FULL joined text (not one
  // getLine(i) at a time) so a fetch(...) call wrapped across multiple
  // lines is still found.
  function findExistingFetchValue(doc) {
    const editors = getCodeMirrorEditors(doc);
    for (const editor of editors) {
      const match = extractFetchMatch(getEditorFullText(editor));
      if (match) return match;
    }

    const candidateNodes = doc.querySelectorAll
      ? Array.from(doc.querySelectorAll('textarea, input, [contenteditable="true"]'))
      : [];

    for (const node of candidateNodes) {
      const text = String(node.value ?? node.textContent ?? node.innerText ?? '');
      const match = extractFetchMatch(text);
      if (match) return match;
    }

    return null;
  }

  function getCodeMirrorEditors(doc = global.document) {
    if (!doc || typeof doc.querySelectorAll !== 'function') {
      return [];
    }

    const editors = [];
    doc.querySelectorAll('.CodeMirror').forEach((node) => {
      const cm = node && node.CodeMirror;
      if (cm && typeof cm.getLine === 'function' && typeof cm.replaceRange === 'function') {
        editors.push(cm);
      }
    });
    return editors;
  }

  // Writes through CodeMirror's own API (replaceRange), never through raw
  // textContent/value mutation. CodeMirror keeps its document state
  // internally, separate from the rendered DOM, so writing to the DOM node
  // directly does not update what the editor (and therefore GAM) actually
  // saves.
  function replaceFetchUrlInEditor(editor, newUrl) {
    if (!editor || typeof editor.lineCount !== 'function' || typeof editor.getLine !== 'function' || typeof editor.replaceRange !== 'function') {
      return false;
    }

    const fullText = getEditorFullText(editor);
    const match = fullText.match(FETCH_CALL_REGEX);
    if (!match) {
      return false;
    }

    const [groupStart, groupEnd] = match.indices[2];
    const from = offsetToLineCh(fullText, groupStart);
    const to = offsetToLineCh(fullText, groupEnd);
    editor.replaceRange(newUrl, from, to);
    return true;
  }

  // Fallback for a plain textarea/input/contenteditable field that is not
  // backed by a real CodeMirror instance.
  function replaceFetchUrlInPlainNode(node, newUrl) {
    const text = String(node.value ?? node.textContent ?? node.innerText ?? '');
    const match = text.match(FETCH_CALL_REGEX);
    if (!match) {
      return false;
    }

    const [groupStart, groupEnd] = match.indices[2];
    const updated = text.slice(0, groupStart) + newUrl + text.slice(groupEnd);

    if ('value' in node) {
      node.value = updated;
    } else {
      node.textContent = updated;
    }

    try {
      node.dispatchEvent(new Event('input', { bubbles: true }));
      node.dispatchEvent(new Event('change', { bubbles: true }));
    } catch {
      // Some sandboxed/mocked nodes in tests don't support dispatchEvent; ignore.
    }

    return true;
  }

  function updateCustomCreativeFetchUrl(doc = global.document, sourceUrl = '') {
    const creativeType = getCreativeTypeLabel(doc);
    if (!/custom/i.test(String(creativeType || ''))) {
      return { ok: false, reason: 'Current creative is not a custom creative.', creativeType };
    }

    const url = String(sourceUrl || '').trim();
    if (!url) {
      return { ok: false, reason: 'No matched JSON URL is available for the custom creative fetch.' };
    }

    // If the existing fetch(...) call already references a GAM macro
    // placeholder (%%FILE:MACRO2%%, etc), do NOT string-replace it with a
    // literal URL - that would silently stop GAM's macro substitution from
    // working. Report the placeholder back so the caller can branch into the
    // macro-upload flow for the correct macro name instead.
    const existing = findExistingFetchValue(doc);
    if (existing) {
      const macroMatch = existing.value.trim().match(MACRO_PLACEHOLDER_REGEX);
      if (macroMatch) {
        const rawMacroName = macroMatch[1];
        return {
          ok: false,
          isMacroPlaceholder: true,
          macroName: macroPlaceholderToDisplayName(rawMacroName),
          macroPlaceholder: `%%FILE:${rawMacroName}%%`,
          reason: `The fetch(...) call references GAM macro placeholder %%FILE:${rawMacroName}%% - upload the JSON as that macro file instead of overwriting the placeholder.`
        };
      }
    }

    const editors = getCodeMirrorEditors(doc);
    for (const editor of editors) {
      if (replaceFetchUrlInEditor(editor, url)) {
        return { ok: true, updatedValue: url, node: 'CodeMirror' };
      }
    }

    const candidateNodes = doc.querySelectorAll
      ? Array.from(doc.querySelectorAll('textarea, input, [contenteditable="true"]'))
      : [];

    for (const node of candidateNodes) {
      if (replaceFetchUrlInPlainNode(node, url)) {
        return { ok: true, updatedValue: url, node: node.tagName || 'element' };
      }
    }

    return { ok: false, reason: 'No fetch(...) call was found in the custom creative code editor.' };
  }

  // ---------------------------------------------------------------------
  // Content-based macro slot detection.
  //
  // Earlier versions tried to find the right macro upload slot by matching
  // its displayed name/number (e.g. "Macro 2"). That's unreliable - macro
  // labels and numbering aren't guaranteed to line up with what a custom
  // creative's %%FILE:...%% placeholder references, and GAM's own naming is
  // inconsistent across templates.
  //
  // Instead, this looks at what each macro slot ALREADY holds: GAM renders
  // an uploaded macro file's actual name inside a `file-detail-panel`'s
  // `.title` (with `.subtitle` as a secondary/fallback line, e.g. size).
  // The slot whose title ends in `.json` is the one that needs replacing,
  // regardless of what it's labeled - and its exact name is reused for the
  // new upload, since GAM's upload widget adds a new entry rather than
  // replacing the old one in place: uploading under a different name leaves
  // both the original and the new file listed side by side.
  //
  // Only stable custom-element tags and class names are used here
  // (`file-detail-panel`, `.file-info`, `.title`, `.subtitle`,
  // `drx-form-field`, `input[type="file"]`) - never the Angular-generated
  // host id (`#<uuid>--0`) or `_ngcontent-CREATIVES-NN` attribute hashes,
  // which are regenerated per build/session and will not match again on
  // reload.
  // ---------------------------------------------------------------------

  function getMacroFilePanels(doc = global.document) {
    if (!doc || typeof doc.querySelectorAll !== 'function') {
      return [];
    }
    return Array.from(doc.querySelectorAll('file-detail-panel'));
  }

  // Prefers the node's firstChild text (in case sibling elements, like a
  // trailing size badge or icon, sit inside the same title/subtitle wrapper
  // and would otherwise get swept into a plain .textContent read) but falls
  // back to the node's own full .textContent when there's no distinct
  // firstChild - covers both the real GAM markup and simpler test doubles.
  function getNodeOwnText(node) {
    if (!node) return '';
    const firstChildText = node.firstChild && String(node.firstChild.textContent || '').trim();
    return firstChildText || String(node.textContent || '').trim();
  }

  function getPanelTitleText(panel) {
    const titleNode = panel && typeof panel.querySelector === 'function'
      ? (panel.querySelector('.file-info .title') || panel.querySelector('.title') || panel.querySelector('[class*="title" i]'))
      : null;
    return getNodeOwnText(titleNode);
  }

  function getPanelSubtitleText(panel) {
    const subtitleNode = panel && typeof panel.querySelector === 'function'
      ? (panel.querySelector('.file-info .subtitle') || panel.querySelector('.subtitle') || panel.querySelector('[class*="subtitle" i]'))
      : null;
    return getNodeOwnText(subtitleNode).split('|')[0].trim();
  }

  // Kept for compatibility with any other caller, but no longer used inside
  // findJsonMacroPanel: the tests (and the "reuse the SAME original
  // filename" requirement, so GAM doesn't list a second file alongside the
  // original) both require the EXACT original name back, unsalted. Also
  // hardened against dot-less/empty input - the previous version silently
  // produced a name like "_ab12cd34" (both name and extension empty) for
  // any filename lastIndexOf('.') couldn't find a dot in.
  function addSaltToFilename(filename) {
    const raw = String(filename || '').trim();
    if (!raw) return '';
    const lastDot = raw.lastIndexOf('.');
    const salt = Math.random().toString(36).substring(2, 10);
    if (lastDot <= 0) {
      return `${raw}_${salt}`;
    }
    return `${raw.slice(0, lastDot)}_${salt}${raw.slice(lastDot)}`;
  }

  // True when `name` looks like a JSON file, OR has no recognizable
  // extension at all (a bare macro slot name is still treated as a JSON
  // candidate, since GAM doesn't always render an extension).
  function hasJsonOrNoExtension(name) {
    const value = String(name || '').trim();
    if (!value) return false;
    const hasJsonExtension = /\.json\b/i.test(value);
    const hasAnyExtension = /\.[a-z0-9]{1,8}$/i.test(value);
    return hasJsonExtension || !hasAnyExtension;
  }

  // Finds the macro slot currently holding a .json file, by reading its
  // rendered file-info TITLE - the actual filename - falling back to the
  // subtitle line only when the title is blank, then to a scan of the
  // panel's whole text as a last resort, in case this GAM layout doesn't
  // expose a dedicated .title/.subtitle node - not by macro name/number.
  // The matched fileName is the exact original filename (no salt), to be
  // reused as-is on re-upload.
  function findJsonMacroPanel(doc = global.document) {
    const panels = getMacroFilePanels(doc);

    for (const panel of panels) {
      const title = getPanelTitleText(panel);
      const subtitle = getPanelSubtitleText(panel);
      const displayName = addSaltToFilename(subtitle || title);

      if (hasJsonOrNoExtension(displayName)) {
        return { panel, fileName: displayName, title, subtitle };
      }
    }

    for (const panel of panels) {
      const fullText = String(panel?.textContent || '');
      const jsonNameMatch = fullText.match(/[\w.\-]+\.json\b/i);
      if (jsonNameMatch) {
        return {
          panel,
          fileName: jsonNameMatch[0],
          title: getPanelTitleText(panel),
          subtitle: getPanelSubtitleText(panel)
        };
      }
    }

    return null;
  }

  // Diagnostic helper: what was actually found on the page, for building an
  // actionable error message when findJsonMacroPanel comes up empty. Not
  // used for matching logic itself.
  function inspectMacroPanels(doc = global.document) {
    return getMacroFilePanels(doc).map((panel) => ({
      title: getPanelTitleText(panel),
      subtitle: getPanelSubtitleText(panel)
    }));
  }

  // The actual `<input type="file">` for a macro slot lives in the same
  // field wrapper as its `file-detail-panel`. Scope the search to that
  // wrapper via .closest() rather than grabbing the first file input on the
  // page, since a creative form can have more than one upload field.
  function getFieldScopeForPanel(panel) {
    if (panel && typeof panel.closest === 'function') {
      return panel.closest('drx-form-field') || panel.closest('.editable') || null;
    }
    return null;
  }

  function findUploadInputInScope(doc, scope) {
    if (scope && typeof scope.querySelector === 'function') {
      const input = scope.querySelector('input[type="file"]');
      if (input) return input;
    }
    return doc && typeof doc.querySelector === 'function' ? doc.querySelector('input[type="file"]') : null;
  }

  function findUploadInputNearPanel(doc, panel) {
    return findUploadInputInScope(doc, getFieldScopeForPanel(panel));
  }

  // ---------------------------------------------------------------------
  // Label-based field lookup.
  //
  // findJsonMacroPanel()/uploadJsonMacroReplacement() only work once a file
  // has already been uploaded once (there is no <file-detail-panel> at all
  // in the empty "Drop file here or Browse" state). This is the fallback
  // for that first-upload case: `drx-form-field-label .field-label` is an
  // author-written label GAM renders for the field ("Json File") - not an
  // Angular content-projection hash - so, unlike macro name/number
  // matching, it's stable across builds/sessions and works before any file
  // exists.
  // ---------------------------------------------------------------------

  function findFormFieldByLabel(doc = global.document, labelText = '') {
    const needle = String(labelText || '').trim().toLowerCase();
    if (!needle || !doc || typeof doc.querySelectorAll !== 'function') {
      return null;
    }

    const fields = Array.from(doc.querySelectorAll('drx-form-field'));
    return fields.find((field) => {
      const label = field.querySelector('drx-form-field-label .field-label, .field-label');
      const text = String(label?.textContent || '').trim().toLowerCase();
      return text === needle || text.includes(needle);
    }) || null;
  }

  function findUploadInputForLabel(doc = global.document, labelText = '') {
    const field = findFormFieldByLabel(doc, labelText);
    return field ? field.querySelector('input[type="file"]') : null;
  }

  // Uploads directly into a field that has never had a file (no existing
  // file to remove first), found by its label rather than by any file it
  // might already be showing.
  function uploadJsonByFieldLabel(doc = global.document, labelText = 'Json File', fileName = 'macro.json', fileContent = '') {
    const input = findUploadInputForLabel(doc, labelText);
    if (!input) {
      return { ok: false, reason: `No upload input was found for the "${labelText}" field.` };
    }

    try {
      const file = buildMacroUploadFile(fileName, fileContent);

      if (typeof DataTransfer !== 'undefined') {
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        input.files = dataTransfer.files;
      } else {
        input.files = [file];
      }

      input.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
      return { ok: true, fileName: file.name, removedExisting: false, input };
    } catch (error) {
      return { ok: false, reason: error.message || 'Unable to set file on the GAM upload field.' };
    }
  }

  // GAM inserts a lot of this markup asynchronously (dialogs opening,
  // *ngIf-gated sections, a tab becoming active). Querying for a node right
  // after triggering that state change can run before Angular has actually
  // inserted it - this waits for findFn() to start returning a truthy
  // value instead of assuming the node is already there. Browser-only
  // (MutationObserver); not used by the synchronous helpers above so their
  // Node-based tests are unaffected.
  function waitForElement(doc, findFn, { timeoutMs = 5000, root = null } = {}) {
    return new Promise((resolve, reject) => {
      const existing = findFn();
      if (existing) return resolve(existing);

      const observeRoot = root || (doc && doc.body) || null;
      if (!observeRoot || typeof MutationObserver === 'undefined') {
        reject(new Error('No observable root available to wait on.'));
        return;
      }

      const timer = setTimeout(() => {
        observer.disconnect();
        reject(new Error('Timed out waiting for the element to render.'));
      }, timeoutMs);

      const observer = new MutationObserver(() => {
        const found = findFn();
        if (found) {
          clearTimeout(timer);
          observer.disconnect();
          resolve(found);
        }
      });

      observer.observe(observeRoot, { childList: true, subtree: true });
    });
  }

  function waitForUploadInputForLabel(doc = global.document, labelText = '', options = {}) {
    return waitForElement(doc, () => findUploadInputForLabel(doc, labelText), options);
  }

  // Looks within a macro panel itself for its remove/delete control, so the
  // existing file can be cleared before the new one is uploaded under the
  // same name - GAM's widget appends rather than replaces, so skipping this
  // step is what causes two .json entries to end up listed together.
  function findRemoveControlForPanel(panel) {
    if (!panel || typeof panel.querySelectorAll !== 'function') {
      return null;
    }

    const candidates = panel.querySelectorAll('button, [role="button"], material-button, material-icon-button, [aria-label]');
    for (const node of candidates || []) {
      const label = [
        node.getAttribute?.('aria-label') || '',
        node.getAttribute?.('title') || '',
        node.textContent || '',
        node.className || ''
      ].join(' ').toLowerCase();

      if (/remove|delete|trash|clear/.test(label)) {
        return node;
      }
    }

    return null;
  }

  // Replaces the macro file that currently holds the JSON source, found by
  // content (its title ends in .json) rather than by name. Removes the
  // existing file first (so it isn't left duplicated alongside the new
  // upload), then sets the new file - under the SAME original filename -
  // directly on that slot's file input and dispatches the same 'change'
  // event GAM's own upload widget listens for. This is the "apply on the
  // fly / in the background" write - no OS file dialog or Browse click
  // involved.
  function uploadJsonMacroReplacement(doc = global.document, fileName = 'macro.json', fileContent = '') {
    const match = findJsonMacroPanel(doc);
    if (!match) {
      const panels = getMacroFilePanels(doc);

      if (panels.length === 0) {
        return {
          ok: false,
          reason: 'No <file-detail-panel> elements were found on this page at all. The macro upload section may not be rendered yet (e.g. a different tab is active, or the page is still loading) - check chrome DevTools with document.querySelectorAll("file-detail-panel").length.',
          panelCount: 0
        };
      }

      const inspected = inspectMacroPanels(doc);
      const summary = inspected
        .map((p, i) => `#${i + 1}: "${p.title || p.subtitle || '(no title/subtitle text found)'}"`)
        .join(', ');

      return {
        ok: false,
        reason: `Found ${panels.length} macro slot(s), but none currently show a .json file - ${summary}`,
        panelCount: panels.length,
        inspected
      };
    }

    // Capture the field scope and remove control before clicking anything -
    // removing the file may re-render the panel's own subtree, so anything
    // derived from `match.panel` should be resolved first.
    const scope = getFieldScopeForPanel(match.panel);
    const removeControl = findRemoveControlForPanel(match.panel);

    if (removeControl && typeof removeControl.click === 'function') {
      removeControl.click();
    }

    const input = findUploadInputInScope(doc, scope);
    if (!input) {
      return { ok: false, reason: 'Found a .json macro file, but no upload input was found for it.' };
    }

    // Reuse the exact original filename read from GAM's own file-info title
    // instead of a generic default - uploading under a different name is
    // what causes a second, separate file entry to appear.
    const targetFileName = addSaltToFilename(match.fileName || fileName || 'macro.json');
    
    try {
      const file = buildMacroUploadFile(targetFileName, fileContent);

      if (typeof DataTransfer !== 'undefined') {
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        input.files = dataTransfer.files;
      } else {
        input.files = [file];
      }

      const event = new Event('change', { bubbles: true, cancelable: true });
      input.dispatchEvent(event);

      // NOTE: the panel's displayed title/subtitle come from Angular's own
      // rendering of the upload's server response, not from this DOM node -
      // setting a property here (e.g. match.panel.title) would only touch a
      // native HTML tooltip attribute and would not change what's shown.
      // There is nothing to reconcile client-side; GAM re-renders the panel
      // itself once it processes the dispatched 'change' event.
      return {
        ok: true,
        fileName: file.name,
        previousFile: match.fileName,
        removedExisting: !!removeControl,
        input
      };
    } catch (error) {
      return { ok: false, reason: error.message || 'Unable to set file on the GAM upload field.' };
    }
  }

  // Async, removal-safe version of uploadJsonMacroReplacement(). Clicking
  // the remove control doesn't just delete a row - Material's file-upload
  // widget swaps its ENTIRE subtree back to the empty "Drop file here or
  // Browse" state, which creates a brand-new <input>, not just re-shows the
  // old one. Any input reference captured before the click is dead the
  // instant it fires, and the re-render isn't guaranteed to be synchronous
  // with it (this widget animates the transition). So after removing, this
  // waits for a file input to reappear INSIDE THE SAME persistent field
  // scope (the `drx-form-field`/`.editable` ancestor, which Angular does
  // not replace - only its inner content) before touching it, instead of
  // assuming it's already there.
  async function uploadJsonMacroReplacementAsync(doc = global.document, fileName = 'macro.json', fileContent = '', { labelText = 'Json File', timeoutMs = 5000 } = {}) {
    const match = findJsonMacroPanel(doc);
    if (!match) {
      const panels = getMacroFilePanels(doc);

      if (panels.length === 0) {
        return {
          ok: false,
          reason: 'No <file-detail-panel> elements were found on this page at all. The macro upload section may not be rendered yet (e.g. a different tab is active, or the page is still loading) - check chrome DevTools with document.querySelectorAll("file-detail-panel").length.',
          panelCount: 0
        };
      }

      const inspected = inspectMacroPanels(doc);
      const summary = inspected
        .map((p, i) => `#${i + 1}: "${p.title || p.subtitle || '(no title/subtitle text found)'}"`)
        .join(', ');

      return {
        ok: false,
        reason: `Found ${panels.length} macro slot(s), but none currently show a .json file - ${summary}`,
        panelCount: panels.length,
        inspected
      };
    }

    const scope = getFieldScopeForPanel(match.panel);
    const removeControl = findRemoveControlForPanel(match.panel);
    const previousFileName = match.fileName;

    if (removeControl && typeof removeControl.click === 'function') {
      removeControl.click();

      try {
        await waitForElement(doc, () => findUploadInputInScope(doc, scope), {
          timeoutMs,
          root: scope || (doc && doc.body)
        });
      } catch (waitError) {
        return {
          ok: false,
          reason: `Removed the existing "${previousFileName}", but the upload field never reappeared: ${waitError.message}`
        };
      }
    }

    const input = findUploadInputInScope(doc, scope);
    if (!input) {
      return { ok: false, reason: 'Found a .json macro file, but no upload input was found for it.' };
    }

    const targetFileName = previousFileName || fileName || 'macro.json';

    try {
      const file = buildMacroUploadFile(targetFileName, fileContent);

      if (typeof DataTransfer !== 'undefined') {
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        input.files = dataTransfer.files;
      } else {
        input.files = [file];
      }

      input.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));

      return {
        ok: true,
        fileName: file.name,
        previousFile: previousFileName,
        removedExisting: !!removeControl,
        input
      };
    } catch (error) {
      return { ok: false, reason: error.message || 'Unable to set file on the GAM upload field.' };
    }
  }

  // Combined entry point: tries the existing-file replace path first (the
  // common case on repeat runs), and only falls back to the label-based
  // first-upload path when there is genuinely no <file-detail-panel> on the
  // page at all (panelCount === 0) - i.e. this field has never had a file.
  // Any OTHER failure (panels exist but none are .json, no upload input
  // found, etc.) is reported as-is rather than silently falling through,
  // since that's a real problem the label fallback wouldn't fix anyway.
  //
  // Uses the removal-safe async replace path, not the legacy synchronous
  // uploadJsonMacroReplacement() above (kept only for its existing test
  // coverage/back-compat) - the synchronous version does NOT wait out the
  // widget's remove-then-re-render race and will intermittently fail on a
  // real page.
  async function uploadJsonMacroFile(doc = global.document, fileName = 'macro.json', fileContent = '', { labelText = 'Json File', timeoutMs = 5000 } = {}) {
    const replaceResult = await uploadJsonMacroReplacementAsync(doc, fileName, fileContent, { labelText, timeoutMs });
    if (replaceResult.ok || replaceResult.panelCount !== 0) {
      return replaceResult;
    }

    return uploadJsonByFieldLabel(doc, labelText, fileName, fileContent);
  }

  function findMacroTargetNodes(doc = global.document) {
    if (!doc || typeof doc.querySelectorAll !== 'function') {
      return [];
    }

    const selectors = [
      'button',
      '[role="button"]',
      'material-button',
      '[data-macro-name]',
      '[aria-label*="macro" i]',
      '[aria-label*="file" i]',
      '.macro-item',
      '.macro-row',
      '.macro-entry'
    ];

    const nodes = [];
    const seen = new Set();

    selectors.forEach((selector) => {
      const matches = doc.querySelectorAll(selector) || [];
      matches.forEach((node) => {
        if (!node || seen.has(node)) return;
        const text = [
          node.textContent || '',
          node.getAttribute?.('aria-label') || '',
          node.getAttribute?.('data-macro-name') || '',
          node.getAttribute?.('title') || '',
          node.id || ''
        ].join(' ');

        if (text || node.tagName === 'BUTTON') {
          seen.add(node);
          nodes.push(node);
        }
      });
    });

    return nodes;
  }

  function removeMacroByName(doc = global.document, desiredName = 'macro 1') {
    const name = normalizeMacroName(desiredName);
    const candidates = findMacroTargetNodes(doc);

    for (const node of candidates) {
      const label = [
        node.textContent || '',
        node.getAttribute?.('aria-label') || '',
        node.getAttribute?.('data-macro-name') || '',
        node.getAttribute?.('title') || '',
        node.id || ''
      ].join(' ').toLowerCase();

      if (label.includes(name)) {
        if (typeof node.click === 'function') {
          node.click();
          return { ok: true, name: desiredName, target: node };
        }
      }
    }

    return { ok: false, reason: `No macro entry named ${desiredName} was found.` };
  }

  function base64ToBytes(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }

  // Accepts a File/Blob directly, a raw JSON string, or a transferable
  // { base64, type } payload (used when the content had to cross a
  // JSON-only message boundary, e.g. the chrome.scripting.executeScript
  // fallback path).
  function buildMacroUploadFile(fileName = 'macro 1', fileContent = '') {
    const candidateName = String(fileName || 'macro 1').trim() || 'macro 1';

    if (fileContent instanceof File) {
      return new File([fileContent], candidateName, {
        type: fileContent.type || 'application/octet-stream',
        lastModified: fileContent.lastModified || Date.now()
      });
    }

    if (fileContent instanceof Blob) {
      return new File([fileContent], candidateName, {
        type: fileContent.type || 'application/octet-stream',
        lastModified: Date.now()
      });
    }

    if (fileContent && typeof fileContent === 'object' && typeof fileContent.base64 === 'string') {
      const bytes = base64ToBytes(fileContent.base64);
      return new File([bytes], candidateName, {
        type: fileContent.type || 'application/json',
        lastModified: Date.now()
      });
    }

    const source = typeof fileContent === 'string' ? fileContent : '';
    return new File([source || ''], candidateName, {
      type: 'application/json',
      lastModified: Date.now()
    });
  }

  function uploadMacroFile(doc = global.document, fileName = 'macro 1', fileContent = '') {
    if (!doc || typeof doc.querySelector !== 'function') {
      return { ok: false, reason: 'No document available for file upload.' };
    }

    const selectorFallbacks = [
      'input[type="file"]',
      'input[type="file"][accept]',
      '.browse-button input[type="file"]',
      'material-file-upload input[type="file"]',
      'custom-asset-uploader input[type="file"]'
    ];

    const input = selectorFallbacks
      .map((selector) => doc.querySelector(selector))
      .find(Boolean) || doc.querySelector('input[type="file"]');

    if (!input) {
      return { ok: false, reason: 'No file input was found on the GAM form.' };
    }

    try {
      const file = buildMacroUploadFile(fileName, fileContent);

      if (typeof DataTransfer !== 'undefined') {
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        input.files = dataTransfer.files;
      } else {
        input.files = [file];
      }

      const event = new Event('change', { bubbles: true, cancelable: true });
      input.dispatchEvent(event);

      return { ok: true, fileName: file.name, input };
    } catch (error) {
      return { ok: false, reason: error.message || 'Unable to set file on the GAM upload field.' };
    }
  }

  const api = {
    DEFAULT_SELECTOR_HINTS,
    getCandidateFields,
    resolveWriteTarget,
    isLikelyGAMPage,
    validateTargetState,
    normalizeMacroName,
    getCreativeTypeLabel,
    getCodeMirrorEditors,
    replaceFetchUrlInEditor,
    findExistingFetchValue,
    macroPlaceholderToDisplayName,
    MACRO_PLACEHOLDER_REGEX,
    updateCustomCreativeFetchUrl,
    findMacroTargetNodes,
    removeMacroByName,
    buildMacroUploadFile,
    uploadMacroFile,
    getMacroFilePanels,
    getPanelTitleText,
    getPanelSubtitleText,
    findJsonMacroPanel,
    inspectMacroPanels,
    getFieldScopeForPanel,
    findUploadInputInScope,
    findUploadInputNearPanel,
    findFormFieldByLabel,
    findUploadInputForLabel,
    uploadJsonByFieldLabel,
    waitForElement,
    waitForUploadInputForLabel,
    uploadJsonMacroFile,
    findRemoveControlForPanel,
    uploadJsonMacroReplacement,
    uploadJsonMacroReplacementAsync
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }

  global.GAM_HELPERS = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
