const DEFAULT_DRIVE_SOURCE_URL = 'https://drive.google.com/file/d/1je54X0abTr10oA-0u0jx8Cnpxg8adBLD/view?usp=sharing';
const SOURCE_LIST_HELPERS = globalThis.SOURCE_LIST_HELPERS || {};
const BATCH_HELPERS = globalThis.BATCH_HELPERS || {};

const statusEl = document.getElementById('status');
const tabStatusEl = document.getElementById('tabStatus');
const creativeTypeBadgeEl = document.getElementById('creativeTypeBadge');
const sourceListInput = document.getElementById('sourceListUrl');
const siteOverrideInput = document.getElementById('siteOverride');
const matchedSiteEl = document.getElementById('matchedSite');
const matchedUrlEl = document.getElementById('matchedUrl');
const macroFileInput = document.getElementById('macroFileInput');
const refreshBtn = document.getElementById('refreshBtn');
const applyBtn = document.getElementById('applyBtn');
const batchBtn = document.getElementById('batchBtn');
const resultsListEl = document.getElementById('resultsList');

let lastMatched = null;

function setStatus(message, type = 'info') {
  if (!statusEl) return;
  statusEl.textContent = message;
  statusEl.className = `status ${type}`;
}

function setCreativeTypeBadge(type) {
  if (!creativeTypeBadgeEl) return;
  const normalized = String(type || '').trim() || 'Unknown';
  const isCustom = /custom/i.test(normalized);
  const textNode = creativeTypeBadgeEl.querySelector('.creative-type-text');
  if (textNode) textNode.textContent = normalized;
  creativeTypeBadgeEl.classList.toggle('custom', isCustom);
  creativeTypeBadgeEl.classList.toggle('standard', !isCustom);
}

function renderMatched(matched) {
  lastMatched = matched || null;
  matchedSiteEl.textContent = matched?.site || '—';
  matchedUrlEl.textContent = matched?.json_url || '—';
}

function renderBatchResults(queue) {
  if (!resultsListEl) return;
  resultsListEl.innerHTML = '';
  queue.forEach((item) => {
    const li = document.createElement('li');
    li.textContent = item.status === 'success'
      ? `✓ ${item.title} (${item.mode})`
      : `✗ ${item.title} — ${item.lastError}`;
    li.className = item.status;
    resultsListEl.appendChild(li);
  });
}

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

async function readConfig() {
  const stored = await chrome.storage.local.get('lagidiskonConfig');
  const config = stored.lagidiskonConfig || {};
  return {
    sourceListUrl: config.sourceListUrl || DEFAULT_DRIVE_SOURCE_URL,
    siteOverride: config.siteOverride || ''
  };
}

async function saveConfig() {
  const sourceListUrl = sourceListInput.value.trim() || DEFAULT_DRIVE_SOURCE_URL;
  const siteOverride = siteOverrideInput.value.trim();
  await chrome.storage.local.set({ lagidiskonConfig: { sourceListUrl, siteOverride } });
}

// ---------------------------------------------------------------------------
// Single source of truth for talking to the active GAM tab: try the content
// script first, and if that fails (timing/injection issues) fall back to
// injecting the *real* gam-helpers.js file and calling it directly - instead
// of keeping a second, hand-copied implementation in sync by hand.
// ---------------------------------------------------------------------------

async function invokeGAMTabAction(tabId, type, payload = {}) {
  try {
    const response = await chrome.tabs.sendMessage(tabId, { type, ...payload });
    if (response) return response;
  } catch {
    // fall through to the script-injection fallback below
  }

  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['gam-helpers.js'] });
  } catch (error) {
    return { ok: false, reason: `Could not reach the active GAM tab: ${error.message}` };
  }

  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: (msgType, msgPayload) => {
        const helpers = window.GAM_HELPERS;
        if (!helpers) {
          return { ok: false, reason: 'GAM helpers could not be loaded on this page.' };
        }

        if (msgType === 'GET_CREATIVE_TYPE') {
          return { ok: true, creativeType: helpers.getCreativeTypeLabel(document) };
        }
        if (msgType === 'UPDATE_CUSTOM_CREATIVE_FETCH_URL') {
          return helpers.updateCustomCreativeFetchUrl(document, msgPayload.value || '');
        }
        if (msgType === 'REMOVE_MACRO_BY_NAME') {
          return helpers.removeMacroByName(document, msgPayload.name || 'macro 1');
        }
        if (msgType === 'UPLOAD_MACRO_FILE') {
          const fileArg = msgPayload.fileBase64
            ? { base64: msgPayload.fileBase64, type: msgPayload.fileType }
            : (msgPayload.file || '');
          return helpers.uploadMacroFile(document, msgPayload.fileName || 'macro 1', fileArg);
        }
        if (msgType === 'UPLOAD_JSON_MACRO_FILE') {
          const fileArg = msgPayload.fileBase64
            ? { base64: msgPayload.fileBase64, type: msgPayload.fileType }
            : (msgPayload.file || '');
          return helpers.uploadJsonMacroReplacement(document, msgPayload.fileName || 'macro.json', fileArg);
        }
        if (msgType === 'WRITE_JSON_FIELD') {
          const target = helpers.resolveWriteTarget(document);
          if (!target) return { ok: false, reason: 'No editable JSON field found.' };
          if (typeof target.value === 'string' || typeof target.value === 'number') {
            target.value = msgPayload.value;
          } else {
            target.textContent = msgPayload.value;
          }
          return { ok: true, fieldLabel: target.name || target.id || 'unknown' };
        }

        return { ok: false, reason: `Unsupported action: ${msgType}` };
      },
      args: [type, payload]
    });

    return results?.[0]?.result || { ok: false, reason: 'No result returned from the page fallback.' };
  } catch (fallbackError) {
    return { ok: false, reason: `Could not run the fallback GAM script: ${fallbackError.message}` };
  }
}

async function refreshCreativeTypeBadge(tab) {
  if (!tab?.id) {
    setCreativeTypeBadge('Unknown');
    return;
  }
  const result = await invokeGAMTabAction(tab.id, 'GET_CREATIVE_TYPE');
  setCreativeTypeBadge(result?.ok ? (result.creativeType || 'Unknown') : 'Unknown');
}

// ---------------------------------------------------------------------------
// Source resolution: fixed Drive/JSON list -> matched {site, json_url}
// ---------------------------------------------------------------------------

async function loadSourceEntries(sourceListUrl) {
  const normalized = typeof SOURCE_LIST_HELPERS.normalizeGoogleDriveUrl === 'function'
    ? SOURCE_LIST_HELPERS.normalizeGoogleDriveUrl(sourceListUrl)
    : sourceListUrl;

  const response = await fetch(normalized, { cache: 'no-store', credentials: 'include' });
  if (!response.ok) {
    throw new Error(`Unable to fetch the source list (${response.status})`);
  }

  const payload = await response.json();
  return typeof SOURCE_LIST_HELPERS.extractSourceEntriesFromPayload === 'function'
    ? SOURCE_LIST_HELPERS.extractSourceEntriesFromPayload(payload)
    : [];
}

function matchEntryForContext(entries, contextText, siteOverride) {
  if (siteOverride) {
    const needle = siteOverride.toLowerCase();
    const direct = entries.find((entry) => {
      const name = String(entry.name || '').toLowerCase();
      const site = String(entry.site || '').toLowerCase();
      return name === needle || site === needle;
    });
    if (direct) return direct;
  }

  return typeof SOURCE_LIST_HELPERS.resolveSourceFromCreativeName === 'function'
    ? SOURCE_LIST_HELPERS.resolveSourceFromCreativeName(entries, contextText)
    : null;
}

async function resolveMatchedSourceForTab(tab) {
  const { sourceListUrl, siteOverride } = await readConfig();
  const entries = await loadSourceEntries(sourceListUrl);
  if (!entries.length) {
    return null;
  }

  let pageText = tab?.title || '';
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => String((document.body ? document.body.innerText : '') || document.title || '').slice(0, 5000)
    });
    pageText = [tab?.title, results?.[0]?.result].filter(Boolean).join(' ');
  } catch {
    // Keep just the tab title if we can't read the page (e.g. chrome:// tabs).
  }

  const matched = matchEntryForContext(entries, pageText, siteOverride);
  return matched ? { site: matched.site || matched.name, json_url: matched.json_url } : null;
}

// ---------------------------------------------------------------------------
// File handling for the macro-upload branch
// ---------------------------------------------------------------------------

async function downloadMatchedJsonAsFile(url) {
  const response = await fetch(url, { cache: 'no-store', credentials: 'include' });
  if (!response.ok) {
    throw new Error(`Unable to download the matched JSON file (${response.status})`);
  }
  const blob = await response.blob();
  return new File([blob], 'macro-1.json', { type: blob.type || 'application/json', lastModified: Date.now() });
}

async function fileToTransferablePayload(file) {
  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return {
    fileBase64: btoa(binary),
    fileType: file.type || 'application/json',
    fileName: file.name || 'macro 1'
  };
}

// ---------------------------------------------------------------------------
// The smart apply flow: custom creative -> replace fetch() URL in CodeMirror.
// Any other (standard/macro) template -> auto remove + upload the file.
// ---------------------------------------------------------------------------

async function applySmartUpdate(tab, matched, { manualFile = null } = {}) {
  if (!matched && !manualFile) {
    return { ok: false, reason: 'No matched JSON URL was found for this tab.' };
  }

  let isMacroPlaceholderBranch = false;

  if (!manualFile) {
    const customResult = await invokeGAMTabAction(tab.id, 'UPDATE_CUSTOM_CREATIVE_FETCH_URL', { value: matched.json_url });

    if (customResult?.ok) {
      return { ok: true, mode: 'custom', detail: 'fetch() URL replaced inside the CodeMirror editor.' };
    }

    if (customResult?.isMacroPlaceholder) {
      // The fetch(...) call already references a GAM macro placeholder.
      // String-replacing it with a literal URL would silently break GAM's
      // own macro substitution, so don't touch the code editor at all -
      // fall through to the macro-file replacement below instead.
      isMacroPlaceholderBranch = true;
    } else if (!customResult?.reason || !/not a custom creative/i.test(customResult.reason)) {
      // Only fall through to the macro-upload flow when this genuinely isn't
      // a custom creative. Any other failure (e.g. no fetch() call present)
      // is reported directly rather than silently trying to upload a file too.
      return { ok: false, reason: customResult?.reason || 'Custom creative update failed.' };
    }
  }

  let file;
  try {
    file = manualFile || await downloadMatchedJsonAsFile(matched.json_url);
  } catch (error) {
    return { ok: false, reason: error.message || 'Could not prepare the macro file.' };
  }

  // Find and replace the macro slot by what it currently holds (a .json
  // file's rendered subtitle), not by a name/number - macro labels aren't a
  // reliable way to identify the right slot. This writes the new file
  // directly and does not require a separate "remove" step first.
  const transferable = await fileToTransferablePayload(file);
  const uploadResult = await invokeGAMTabAction(tab.id, 'UPLOAD_JSON_MACRO_FILE', {
    fileName: file.name || 'macro.json',
    fileBase64: transferable.fileBase64,
    fileType: transferable.fileType
  });

  if (uploadResult?.ok) {
    const sameNameReplace = uploadResult.previousFile && uploadResult.previousFile === uploadResult.fileName;
    const detail = sameNameReplace
      ? `Replaced ${uploadResult.fileName} with an updated copy (same filename).`
      : `Replaced ${uploadResult.previousFile || 'the existing macro file'} with ${uploadResult.fileName}.`;

    return {
      ok: true,
      mode: isMacroPlaceholderBranch ? 'macro-placeholder' : 'macro',
      detail
    };
  }

  return { ok: false, reason: uploadResult?.reason || 'The macro file upload did not complete.' };
}

// ---------------------------------------------------------------------------
// UI actions
// ---------------------------------------------------------------------------

async function refreshMatch() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    setStatus('No active browser tab is available.', 'error');
    return;
  }

  setStatus('Looking up the matched JSON URL...', 'info');
  await refreshCreativeTypeBadge(tab);

  try {
    const matched = await resolveMatchedSourceForTab(tab);
    renderMatched(matched);
    setStatus(matched
      ? `Matched: ${matched.site} → ${matched.json_url}`
      : 'No matching source was found for this tab.', matched ? 'success' : 'info');
  } catch (error) {
    setStatus(`Could not resolve a matched source: ${error.message}`, 'error');
  }
}

async function applyToActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    setStatus('No active browser tab is available.', 'error');
    return;
  }

  setStatus('Applying update...', 'info');
  const matched = lastMatched || await resolveMatchedSourceForTab(tab);
  if (!matched) {
    setStatus('No matched JSON URL was found for this tab.', 'error');
    return;
  }
  renderMatched(matched);

  console.log('applyToActiveTab: matched', matched, { tabId: tab.id, title: tab.title, url: tab.url });

  const result = await applySmartUpdate(tab, matched);
  if (result.ok) {
    const modeLabel = result.mode === 'custom'
      ? 'Custom creative updated.'
      : result.mode === 'macro-placeholder'
        ? 'Macro placeholder detected — uploaded as macro file.'
        : 'Macro upload complete.';
    setStatus(`${modeLabel} ${result.detail || ''}`.trim(), 'success');
  } else {
    setStatus(result.reason || 'Update failed.', 'error');
  }
}

async function applyToAllTabs() {
  const tabs = await chrome.tabs.query({});
  const queue = typeof BATCH_HELPERS.buildTabQueue === 'function' ? BATCH_HELPERS.buildTabQueue(tabs) : [];

  if (!queue.length) {
    setStatus('No open GAM tabs were found.', 'error');
    return;
  }

  setStatus(`Applying update to ${queue.length} open GAM tab(s)...`, 'info');
  let successCount = 0;

  for (const item of queue) {
    const tabRef = { id: item.tabId, title: item.title };
    try {
      const matched = await resolveMatchedSourceForTab(tabRef);
      if (!matched) {
        item.status = 'failed';
        item.lastError = 'No matched source found for this tab.';
        continue;
      }
      const result = await applySmartUpdate(tabRef, matched);
      item.status = result.ok ? 'success' : 'failed';
      item.mode = result.mode || '';
      item.lastError = result.ok ? '' : (result.reason || 'Update failed.');
      if (result.ok) successCount += 1;
    } catch (error) {
      item.status = 'failed';
      item.lastError = error.message || 'Unexpected error.';
    }
  }

  renderBatchResults(queue);
  setStatus(`Batch complete: ${successCount}/${queue.length} tab(s) updated.`, successCount === queue.length ? 'success' : 'error');
}

async function applyManualFile(file) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    setStatus('No active browser tab is available.', 'error');
    return;
  }

  setStatus(`Uploading ${file.name} manually...`, 'info');
  const result = await applySmartUpdate(tab, lastMatched, { manualFile: file });
  if (result.ok) {
    setStatus(`Manual upload complete. ${result.detail || ''}`.trim(), 'success');
  } else {
    setStatus(result.reason || 'Manual upload failed.', 'error');
  }
}

async function hydrate() {
  const { sourceListUrl, siteOverride } = await readConfig();
  sourceListInput.value = sourceListUrl;
  siteOverrideInput.value = siteOverride;

  const { url, title } = await chrome.runtime.sendMessage({ type: 'READ_ACTIVE_TAB' });
  if (tabStatusEl) {
    tabStatusEl.textContent = url ? `${title || 'Active page'} • ${url}` : 'No active tab available';
  }

  await refreshMatch();
}

sourceListInput.addEventListener('change', saveConfig);
siteOverrideInput.addEventListener('change', saveConfig);
refreshBtn.addEventListener('click', refreshMatch);
applyBtn.addEventListener('click', applyToActiveTab);
batchBtn.addEventListener('click', applyToAllTabs);

macroFileInput.addEventListener('change', async (event) => {
  const [file] = event.target.files || [];
  if (!file) return;
  await applyManualFile(file);
  event.target.value = '';
});

hydrate();
