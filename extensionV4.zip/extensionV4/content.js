const helpers = globalThis.GAM_HELPERS || window.GAM_HELPERS;

function resolveWriteTarget() {
  if (!helpers || typeof helpers.resolveWriteTarget !== 'function') {
    return null;
  }

  return helpers.resolveWriteTarget(document);
}

function getPageGuardState(target) {
  const isStale = !(helpers && typeof helpers.isLikelyGAMPage === 'function')
    ? false
    : !helpers.isLikelyGAMPage(window.location.href);

  return helpers && typeof helpers.validateTargetState === 'function'
    ? helpers.validateTargetState({ pageIsStale: isStale, target })
    : { ok: !!target, reason: target ? 'Target is ready for update.' : 'No editable JSON field found in the current page.' };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'GET_CREATIVE_TYPE') {
    const type = helpers && typeof helpers.getCreativeTypeLabel === 'function'
      ? helpers.getCreativeTypeLabel(document)
      : '';
    sendResponse({ ok: true, creativeType: type });
    return true;
  }

  if (message?.type === 'REMOVE_MACRO_BY_NAME') {
    const result = helpers && typeof helpers.removeMacroByName === 'function'
      ? helpers.removeMacroByName(document, message.name || 'macro 1')
      : { ok: false, reason: 'Macro removal helper is not available.' };
    sendResponse(result);
    return true;
  }

  if (message?.type === 'UPLOAD_MACRO_FILE') {
    // Accept either a transferable { fileBase64, fileType } payload (preferred -
    // survives message passing reliably) or a legacy raw File/string.
    const fileArg = message.fileBase64
      ? { base64: message.fileBase64, type: message.fileType }
      : (message.file || message.content || message.value || '');

    const result = helpers && typeof helpers.uploadMacroFile === 'function'
      ? helpers.uploadMacroFile(document, message.fileName || 'macro 1', fileArg)
      : { ok: false, reason: 'Macro upload helper is not available.' };
    sendResponse(result);
    return true;
  }

  if (message?.type === 'UPLOAD_JSON_MACRO_FILE') {
    // Finds the macro slot by what it currently holds (a .json file's
    // rendered subtitle), not by a name/number, and replaces it directly.
    const fileArg = message.fileBase64
      ? { base64: message.fileBase64, type: message.fileType }
      : (message.file || message.content || message.value || '');
console.log('UPLOAD_JSON_MACRO_FILE', { fileArg, fileName: message.fileName }, message);

    const result = helpers && typeof helpers.uploadJsonMacroReplacement === 'function'
      ? helpers.uploadJsonMacroReplacement(document, message.fileName || 'macro.json', fileArg)
      : { ok: false, reason: 'JSON macro upload helper is not available.' };
    sendResponse(result);
    return true;
  }

  if (message?.type === 'UPDATE_CUSTOM_CREATIVE_FETCH_URL') {
    const result = helpers && typeof helpers.updateCustomCreativeFetchUrl === 'function'
      ? helpers.updateCustomCreativeFetchUrl(document, message.value || message.url || '')
      : { ok: false, reason: 'Custom creative fetch helper is not available.' };
    sendResponse(result);
    return true;
  }

  if (message?.type !== 'WRITE_JSON_FIELD') {
    return false;
  }

  const { value } = message;
  const target = resolveWriteTarget();
  const guard = getPageGuardState(target);

  if (!guard.ok) {
    sendResponse({ ok: false, reason: guard.reason });
    return true;
  }

  try {
    const previousValue = target.value ?? target.textContent ?? '';
    if (typeof target.value === 'string' || typeof target.value === 'number') {
      target.value = value;
    } else if (typeof target.textContent === 'string') {
      target.textContent = value;
    } else {
      target.setAttribute('value', value);
    }

    const updated = String(target.value ?? target.textContent ?? target.getAttribute('value') ?? '').trim();
    sendResponse({
      ok: updated === String(value).trim(),
      previousValue,
      updatedValue: updated,
      fieldLabel: target.name || target.id || target.getAttribute('aria-label') || 'unknown'
    });
    return true;
  } catch (error) {
    sendResponse({ ok: false, reason: error.message || 'Field update failed.' });
    return true;
  }
});
