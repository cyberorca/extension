const test = require('node:test');
const assert = require('node:assert/strict');
const {
  isLikelyGAMPage,
  resolveWriteTarget,
  validateTargetState,
  updateCustomCreativeFetchUrl,
  replaceFetchUrlInEditor
} = require('./gam-helpers.js');

function mockDocumentWithFields(fields) {
  const all = fields.map((field) => ({
    ...field,
    value: field.value || '',
    getAttribute(name) {
      return field.attributes?.[name] ?? null;
    }
  }));

  return {
    querySelectorAll(selector) {
      return all.filter((field) => {
        const name = (field.name || '').toLowerCase();
        const id = (field.id || '').toLowerCase();
        const label = (field.label || '').toLowerCase();
        const placeholder = (field.placeholder || '').toLowerCase();
        const haystacks = [name, id, label, placeholder].join(' ');
        return haystacks.includes('json') || haystacks.includes('url');
      });
    }
  };
}

test('isLikelyGAMPage detects Google Ad Manager URLs', () => {
  assert.equal(isLikelyGAMPage('https://admanager.google.com/1234567#creatives'), true);
  assert.equal(isLikelyGAMPage('https://example.com/some-page'), false);
});

test('resolveWriteTarget picks the most likely JSON field', () => {
  const doc = mockDocumentWithFields([
    { name: 'creativeName', value: 'abc' },
    { name: 'jsonUrl', value: 'https://cdn.example.com/data.json' },
    { id: 'creative-url', value: '' }
  ]);

  const target = resolveWriteTarget(doc);
  assert.equal(target?.name, 'jsonUrl');
});

test('validateTargetState rejects missing field and stale page state', () => {
  const missing = validateTargetState({ pageIsStale: true, target: null });
  assert.equal(missing.ok, false);
  assert.match(missing.reason, /stale|missing/i);

  const good = validateTargetState({ pageIsStale: false, target: { value: 'old' } });
  assert.equal(good.ok, true);
});

function makeCustomDoc(editorNode) {
  return {
    querySelectorAll(selector) {
      if (selector === '.subheader-item') {
        return [{ textContent: 'Creative type: Custom' }];
      }
      if (selector === '.CodeMirror') {
        return [];
      }
      if (selector === 'textarea, input, [contenteditable="true"]') {
        return [editorNode];
      }
      return [];
    }
  };
}

test('updateCustomCreativeFetchUrl rejects non-custom creatives', () => {
  const editor = {
    tagName: 'TEXTAREA',
    value: 'fetch("")',
    dispatchEvent() {}
  };

  const nonCustomDoc = {
    querySelectorAll(selector) {
      if (selector === '.subheader-item') {
        return [{ textContent: 'Creative type: Third party' }];
      }
      if (selector === '.CodeMirror') return [];
      return [editor];
    }
  };

  const result = updateCustomCreativeFetchUrl(nonCustomDoc, 'https://cdn.example.com/site.json');
  assert.equal(result.ok, false);
  assert.match(result.reason, /not a custom creative/i);
});

test('updateCustomCreativeFetchUrl fills a freshly-templated empty fetch("")', () => {
  const editor = { tagName: 'TEXTAREA', value: 'fetch("")', dispatchEvent() {} };
  const doc = makeCustomDoc(editor);

  const result = updateCustomCreativeFetchUrl(doc, 'https://cdn.example.com/site.json');
  assert.equal(result.ok, true);
  assert.match(editor.value, /fetch\("https:\/\/cdn\.example\.com\/site\.json"\)/);
});

test('updateCustomCreativeFetchUrl replaces an EXISTING fetch URL, not just an empty one', () => {
  const editor = {
    tagName: 'TEXTAREA',
    value: 'const data = await fetch("https://old-cdn.example.com/stale.json").then(r => r.json());',
    dispatchEvent() {}
  };
  const doc = makeCustomDoc(editor);

  const result = updateCustomCreativeFetchUrl(doc, 'https://cdn.example.com/new-site.json');
  assert.equal(result.ok, true);
  assert.match(editor.value, /fetch\("https:\/\/cdn\.example\.com\/new-site\.json"\)/);
  assert.doesNotMatch(editor.value, /old-cdn\.example\.com/);
});

test('updateCustomCreativeFetchUrl writes through the CodeMirror API, not raw DOM text', () => {
  const calls = [];
  const cmInstance = {
    lineCount: () => 2,
    getLine: (i) => (i === 1 ? 'fetch("https://old.example.com/a.json")' : 'const x = 1;'),
    replaceRange: (text, from, to) => calls.push({ text, from, to })
  };

  const doc = {
    querySelectorAll(selector) {
      if (selector === '.subheader-item') {
        return [{ textContent: 'Creative type: Custom' }];
      }
      if (selector === '.CodeMirror') {
        return [{ CodeMirror: cmInstance }];
      }
      return [];
    }
  };

  const result = updateCustomCreativeFetchUrl(doc, 'https://cdn.example.com/new.json');
  assert.equal(result.ok, true);
  assert.equal(result.node, 'CodeMirror');
  assert.equal(calls.length, 1);
  assert.match(calls[0].text, /fetch\("https:\/\/cdn\.example\.com\/new\.json"\)/);
});

test('updateCustomCreativeFetchUrl detects a GAM macro placeholder and refuses to overwrite it', () => {
  const cmInstance = {
    lineCount: () => 1,
    getLine: () => 'const data = await fetch("%%FILE:MACRO2%%").then(r => r.json());',
    replaceRange: () => { throw new Error('should not be called - placeholder must not be overwritten'); }
  };

  const doc = {
    querySelectorAll(selector) {
      if (selector === '.subheader-item') {
        return [{ textContent: 'Creative type: Custom' }];
      }
      if (selector === '.CodeMirror') {
        return [{ CodeMirror: cmInstance }];
      }
      return [];
    }
  };

  const result = updateCustomCreativeFetchUrl(doc, 'https://cdn.example.com/new.json');
  assert.equal(result.ok, false);
  assert.equal(result.isMacroPlaceholder, true);
  assert.equal(result.macroName, 'Macro 2');
  assert.equal(result.macroPlaceholder, '%%FILE:MACRO2%%');
  assert.match(result.reason, /macro placeholder/i);
});

function makePanel({ title = '', subtitle = '', removeControl = null } = {}) {
  return {
    querySelector(selector) {
      if (selector === '.file-info .title' || selector === '.title') return title ? { textContent: title } : null;
      if (selector === '.file-info .subtitle' || selector === '.subtitle') return subtitle ? { textContent: subtitle } : null;
      return null;
    },
    querySelectorAll() {
      return removeControl ? [removeControl] : [];
    },
    closest: null // set per-test where needed
  };
}

test('findJsonMacroPanel finds the macro slot whose uploaded file TITLE is a .json, not by name/number', () => {
  const { findJsonMacroPanel } = require('./gam-helpers.js');

  const imagePanel = makePanel({ title: 'fallback-creative.png', subtitle: '12 KB' });
  const jsonPanel = makePanel({ title: 'bola-net-source.json', subtitle: '4 KB' });

  const doc = {
    querySelectorAll(selector) {
      if (selector === 'file-detail-panel') return [imagePanel, jsonPanel];
      return [];
    }
  };

  const match = findJsonMacroPanel(doc);
  assert.equal(match.panel, jsonPanel);
  assert.equal(match.fileName, 'bola-net-source.json');
});

test('findJsonMacroPanel falls back to the subtitle when a panel has no .title', () => {
  const { findJsonMacroPanel } = require('./gam-helpers.js');
  const jsonPanel = makePanel({ subtitle: 'merdeka-source.json' });
  const doc = { querySelectorAll: (selector) => (selector === 'file-detail-panel' ? [jsonPanel] : []) };

  const match = findJsonMacroPanel(doc);
  assert.equal(match.fileName, 'merdeka-source.json');
});

test('findJsonMacroPanel returns null when no macro slot holds a .json file', () => {
  const { findJsonMacroPanel } = require('./gam-helpers.js');
  const imagePanel = makePanel({ title: 'fallback-creative.png' });
  const doc = { querySelectorAll: () => [imagePanel] };
  assert.equal(findJsonMacroPanel(doc), null);
});

test('findRemoveControlForPanel finds a remove/delete control within the panel by label', () => {
  const { findRemoveControlForPanel } = require('./gam-helpers.js');
  const removeButton = { getAttribute: (name) => (name === 'aria-label' ? 'Remove file' : null), textContent: '' };
  const panel = { querySelectorAll: () => [removeButton] };
  assert.equal(findRemoveControlForPanel(panel), removeButton);
});

test('uploadJsonMacroReplacement removes the existing file, reuploads under the SAME original name, and dispatches change', () => {
  const { uploadJsonMacroReplacement } = require('./gam-helpers.js');

  const fileInput = {
    type: 'file',
    files: null,
    changeEvents: 0,
    dispatchEvent(event) {
      if (event.type === 'change') this.changeEvents += 1;
      return true;
    }
  };
  const fieldScope = { querySelector: (selector) => (selector === 'input[type="file"]' ? fileInput : null) };
  const removeControl = { clicked: false, click() { this.clicked = true; }, getAttribute: (n) => (n === 'aria-label' ? 'Remove' : null), textContent: '' };

  const jsonPanel = makePanel({ title: 'bola-net-source.json', removeControl });
  jsonPanel.closest = (selector) => (selector === 'drx-form-field' ? fieldScope : null);

  const doc = {
    querySelectorAll(selector) {
      if (selector === 'file-detail-panel') return [jsonPanel];
      return [];
    }
  };

  // Even though a different fileName default is passed in, the ORIGINAL
  // panel title ("bola-net-source.json") must win, to avoid ending up with
  // two .json entries listed side by side.
  const result = uploadJsonMacroReplacement(doc, 'macro.json', '{"json_url":"https://cdn.example.com/a.json"}');

  assert.equal(result.ok, true);
  assert.equal(removeControl.clicked, true);
  assert.equal(result.removedExisting, true);
  assert.equal(result.previousFile, 'bola-net-source.json');
  assert.equal(result.fileName, 'bola-net-source.json');
  assert.equal(fileInput.changeEvents, 1);
  assert.ok(fileInput.files);
});

test('uploadJsonMacroReplacement still uploads (best-effort) when no remove control is found', () => {
  const { uploadJsonMacroReplacement } = require('./gam-helpers.js');

  const fileInput = { type: 'file', files: null, dispatchEvent: () => true };
  const fieldScope = { querySelector: (selector) => (selector === 'input[type="file"]' ? fileInput : null) };

  const jsonPanel = makePanel({ title: 'old.json' });
  jsonPanel.closest = (selector) => (selector === 'drx-form-field' ? fieldScope : null);

  const doc = { querySelectorAll: (selector) => (selector === 'file-detail-panel' ? [jsonPanel] : []) };

  const result = uploadJsonMacroReplacement(doc, 'macro.json', '{}');
  assert.equal(result.ok, true);
  assert.equal(result.removedExisting, false);
  assert.equal(result.fileName, 'old.json');
});

test('uploadJsonMacroReplacement gives a specific reason when NO file-detail-panel exists at all', () => {
  const { uploadJsonMacroReplacement } = require('./gam-helpers.js');
  const doc = { querySelectorAll: () => [] };
  const result = uploadJsonMacroReplacement(doc);
  assert.equal(result.ok, false);
  assert.equal(result.panelCount, 0);
  assert.match(result.reason, /No <file-detail-panel> elements were found/);
});

test('uploadJsonMacroReplacement lists what WAS found when panels exist but none are .json', () => {
  const { uploadJsonMacroReplacement } = require('./gam-helpers.js');
  const imagePanel = makePanel({ title: 'fallback-creative.png' });
  const emptyPanel = makePanel({});
  const doc = { querySelectorAll: (selector) => (selector === 'file-detail-panel' ? [imagePanel, emptyPanel] : []) };

  const result = uploadJsonMacroReplacement(doc);
  assert.equal(result.ok, false);
  assert.equal(result.panelCount, 2);
  assert.match(result.reason, /fallback-creative\.png/);
  assert.match(result.reason, /no title\/subtitle text found/);
});

test('findJsonMacroPanel falls back to scanning full panel text when no .title/.subtitle node exists', () => {
  const { findJsonMacroPanel } = require('./gam-helpers.js');
  const panel = {
    querySelector: () => null,
    textContent: 'Uploaded file: source-data.json (3.1 KB) — replace'
  };
  const doc = { querySelectorAll: (selector) => (selector === 'file-detail-panel' ? [panel] : []) };

  const match = findJsonMacroPanel(doc);
  assert.ok(match);
  assert.equal(match.fileName, 'source-data.json');
});

test('macroPlaceholderToDisplayName formats macro names to match GAM row labels', () => {
  const { macroPlaceholderToDisplayName } = require('./gam-helpers.js');
  assert.equal(macroPlaceholderToDisplayName('MACRO2'), 'Macro 2');
  assert.equal(macroPlaceholderToDisplayName('MACRO10'), 'Macro 10');
  assert.equal(macroPlaceholderToDisplayName(''), 'Macro 1');
});

test('replaceFetchUrlInEditor returns false when there is no fetch(...) call', () => {
  const cmInstance = {
    lineCount: () => 1,
    getLine: () => 'console.log("no fetch here");',
    replaceRange: () => { throw new Error('should not be called'); }
  };

  assert.equal(replaceFetchUrlInEditor(cmInstance, 'https://cdn.example.com/x.json'), false);
});

test('removeMacroByName removes the macro row named macro 1 and uploadMacroFile populates the file input', () => {
  const macroNodes = [
    { textContent: 'Macro 1', click() { this.removed = true; } },
    { textContent: 'Macro 2', click() { this.removed = true; } }
  ];

  const fileInput = {
    type: 'file',
    files: null,
    dispatchEvent() { return true; }
  };

  const doc = {
    querySelectorAll(selector) {
      if (selector.includes('button') || selector.includes('macro') || selector.includes('role') || selector.includes('aria-label')) {
        return macroNodes;
      }
      return [];
    },
    querySelector(selector) {
      if (selector.includes('input[type="file"]') || selector.includes('input[type="file"][accept]') || selector.includes('browse-button')) {
        return fileInput;
      }
      return null;
    }
  };

  const { removeMacroByName, uploadMacroFile, buildMacroUploadFile } = require('./gam-helpers.js');
  const removed = removeMacroByName(doc, 'macro 1');
  const prepared = buildMacroUploadFile('macro 1', '{"ok":true}');
  const uploaded = uploadMacroFile(doc, 'macro 1', prepared);

  assert.equal(removed.ok, true);
  assert.equal(prepared instanceof File || prepared instanceof Blob, true);
  assert.equal(uploaded.ok, true);
  assert.equal(uploaded.fileName, 'macro 1');
});

test('buildMacroUploadFile reconstructs a File from a transferable base64 payload', () => {
  const { buildMacroUploadFile } = require('./gam-helpers.js');
  const original = Buffer.from('{"json_url":"https://cdn.example.com/a.json"}', 'utf8').toString('base64');
  const file = buildMacroUploadFile('macro 1', { base64: original, type: 'application/json' });

  assert.equal(file instanceof File, true);
  assert.equal(file.name, 'macro 1');
  assert.equal(file.type, 'application/json');
});
