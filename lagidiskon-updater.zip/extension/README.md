# Lagidiskon Updater Extension

A Chrome MV3 extension for internal AdOps work in Google Ad Manager (GAM). It resolves the correct JSON source URL for the current creative and applies it automatically:

- **Custom creatives** — replaces the URL inside the `fetch(...)` call in the CodeMirror code editor, using CodeMirror's own `replaceRange` API (not raw DOM text mutation, and not limited to only filling in a blank `fetch("")` — it also replaces an existing URL on repeat runs).
- **Standard/macro templates** — removes Macro 1 and uploads the matched JSON file automatically, no manual steps.

It uses the active, already-authenticated browser tab and does not call the GAM API.

## What's included
- Manifest V3 project
- Popup UI: source list config, site override, matched-source preview, single-tab apply, multi-tab batch apply, manual file override
- `chrome.storage.local` for the saved source list URL/site override
- `gam-helpers.js`: all GAM DOM detection/mutation logic, shared by both the content script and the `chrome.scripting.executeScript` fallback path (single source of truth — no duplicated logic to keep in sync)
- `source-list.js`: Google Drive/JSON list normalization and site matching
- `batch-helpers.js`: builds the queue of open GAM tabs for the "Apply to All Open GAM Tabs" batch action
- Node test suite for the helpers

## Load the extension in Chrome
1. Open Chrome and go to `chrome://extensions`.
2. Enable Developer mode.
3. Click **Load unpacked**.
4. Select the `extension` directory.

## Zip-based distribution
```bash
cd /Users/kly/Documents/GAM-JSON-UPDATER
zip -r lagidiskon-updater.zip extension
```

## Dry-run validation
```bash
cd /Users/kly/Documents/GAM-JSON-UPDATER
node extension/validate-dry-run.js
node --test extension/gam-helpers.test.js extension/source-list.test.js extension/batch-helpers.test.js
```

## Operational runbook
See [extension/runbook.md](runbook.md) for the step-by-step AdOps flow, batch execution, manual override, and troubleshooting table.

## Design notes / what changed from the original scaffold
- **Fixed bug**: `updateCustomCreativeFetchUrl` previously only matched an *empty* `fetch("")` call via regex, so it never worked on a creative that already had a URL in it (i.e. every real-world run after the first). It also wrote directly to `textContent`/`value` instead of going through CodeMirror's API, so even a match wouldn't reliably persist. Both are fixed in `gam-helpers.js`.
- **Removed duplicated logic**: the old popup had a second, hand-copied implementation of the GAM helpers inlined inside a `chrome.scripting.executeScript` fallback, which had drifted out of sync with the primary implementation. The fallback now injects the real `gam-helpers.js` file and calls it directly.
- **Simplified the popup**: replaced the six mostly-unused source-URL fields and the separate "batch same value into one field" flow with a single source list URL + one **Apply** action that automatically branches into the custom-creative or macro-upload path, matching the actual GAM workflow.
- **Real batch support**: "batch" now means applying the update across every open GAM tab, matched per-tab, rather than writing several source values into one field on one tab.
- **Reliable file transfer**: macro file uploads are base64-encoded before crossing the extension messaging boundary instead of relying on a `File` object surviving message passing, which is safer whether or not the primary content-script path or the scripting fallback is used.
