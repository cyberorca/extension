(function (global) {
  const DEFAULT_SELECTOR_HINTS = [
    "input[name*='json' i]",
    "input[name*='url' i]",
    "textarea[name*='json' i]",
    "textarea[name*='url' i]",
    "input[id*='json' i]",
    "input[id*='url' i]",
    "textarea[id*='json' i]",
    "textarea[id*='url' i]",
    "[aria-label*='json' i]",
    "[aria-label*='url' i]",
    "[placeholder*='json' i]",
    "[placeholder*='url' i]"
  ];

  function getCandidateFields(doc = global.document) {
    if (!doc || typeof doc.querySelectorAll !== 'function') {
      return [];
    }

    const fields = new Set();
    DEFAULT_SELECTOR_HINTS.forEach((selector) => {
      doc.querySelectorAll(selector).forEach((field) => fields.add(field));
    });
    return [...fields];
  }

  function scoreField(field) {
    if (!field || typeof field !== 'object') return 0;

    const text = [
      field.name || '',
      field.id || '',
      field.getAttribute?.('aria-label') || '',
      field.getAttribute?.('placeholder') || '',
      field.value || ''
    ].join(' ').toLowerCase();

    let score = 0;
    if (text.includes('json')) score += 4;
    if (text.includes('url')) score += 3;
    if (text.includes('creative')) score += 2;
    if (field.tagName === 'INPUT') score += 1;
    if (field.tagName === 'TEXTAREA') score += 2;
    if (field.readOnly) score -= 5;
    return score;
  }

  function resolveWriteTarget(doc = global.document) {
    const candidates = getCandidateFields(doc)
      .filter((field) => field && !field.disabled)
      .sort((a, b) => scoreField(b) - scoreField(a));

    return candidates[0] || null;
  }

  function isLikelyGAMPage(url = (global.location ? global.location.href : '')) {
    if (!url) return false;
    const href = String(url).toLowerCase();
    const isGAMHost = href.includes('admanager.google.com') || href.includes('google.com/dfp') || href.includes('googleadmanager');
    const isCreativeContext = href.includes('creative') || href.includes('inventory') || href.includes('order');
    return isGAMHost && (isCreativeContext || href.includes('creative') || href.includes('inventory'));
  }

  function validateTargetState({ pageIsStale = false, target = null }) {
    if (pageIsStale) {
      return { ok: false, reason: 'The current page appears stale or not on the GAM edit screen.' };
    }

    if (!target) {
      return { ok: false, reason: 'No editable JSON field found in the current page.' };
    }

    return { ok: true, reason: 'Target is ready for update.' };
  }

  function normalizeMacroName(value) {
    return String(value || '').trim().toLowerCase().replace(/\s+/g, ' ');
  }

  function getCreativeTypeLabel(doc = global.document) {
    if (!doc || typeof doc.querySelectorAll !== 'function') {
      return '';
    }

    const subheaderItems = Array.from(doc.querySelectorAll('.subheader-item'));
    for (const item of subheaderItems) {
      const text = (item.textContent || '').replace(/\s+/g, ' ').trim();
      if (/^creative type\s*:/i.test(text)) {
        return text.replace(/^creative type\s*:/i, '').trim();
      }
    }

    return '';
  }

  // Matches fetch("..."), fetch('...') or fetch(`...`) with ANY content inside
  // the quotes (including none) - not just an empty fetch("") call. This is
  // what makes replacing an *existing* URL on a second/third run work, not
  // just filling in a freshly-templated blank creative.
  const FETCH_CALL_REGEX = /fetch\(\s*(['"`])([\s\S]*?)\1/;

  function getCodeMirrorEditors(doc = global.document) {
    if (!doc || typeof doc.querySelectorAll !== 'function') {
      return [];
    }

    const editors = [];
    doc.querySelectorAll('.CodeMirror').forEach((node) => {
      const cm = node && node.CodeMirror;
      if (cm && typeof cm.getLine === 'function' && typeof cm.replaceRange === 'function') {
        editors.push(cm);
      }
    });
    return editors;
  }

  // Writes through CodeMirror's own API (replaceRange), never through raw
  // textContent/value mutation. CodeMirror keeps its document state
  // internally, separate from the rendered DOM, so writing to the DOM node
  // directly does not update what the editor (and therefore GAM) actually
  // saves.
  function replaceFetchUrlInEditor(editor, newUrl) {
    if (!editor || typeof editor.lineCount !== 'function' || typeof editor.getLine !== 'function' || typeof editor.replaceRange !== 'function') {
      return false;
    }

    const lineCount = editor.lineCount();
    for (let i = 0; i < lineCount; i++) {
      const lineText = editor.getLine(i);
      const match = lineText.match(FETCH_CALL_REGEX);

      if (match) {
        const quote = match[1];
        const newLineText = lineText.replace(FETCH_CALL_REGEX, `fetch(${quote}${newUrl}${quote}`);
        editor.replaceRange(newLineText, { line: i, ch: 0 }, { line: i, ch: lineText.length });
        return true;
      }
    }

    return false;
  }

  // Fallback for a plain textarea/input/contenteditable field that is not
  // backed by a real CodeMirror instance.
  function replaceFetchUrlInPlainNode(node, newUrl) {
    const text = String(node.value ?? node.textContent ?? node.innerText ?? '');
    const match = text.match(FETCH_CALL_REGEX);
    if (!match) {
      return false;
    }

    const quote = match[1];
    const updated = text.replace(FETCH_CALL_REGEX, `fetch(${quote}${newUrl}${quote}`);

    if ('value' in node) {
      node.value = updated;
    } else {
      node.textContent = updated;
    }

    try {
      node.dispatchEvent(new Event('input', { bubbles: true }));
      node.dispatchEvent(new Event('change', { bubbles: true }));
    } catch {
      // Some sandboxed/mocked nodes in tests don't support dispatchEvent; ignore.
    }

    return true;
  }

  function updateCustomCreativeFetchUrl(doc = global.document, sourceUrl = '') {
    const creativeType = getCreativeTypeLabel(doc);
    if (!/custom/i.test(String(creativeType || ''))) {
      return { ok: false, reason: 'Current creative is not a custom creative.', creativeType };
    }

    const url = String(sourceUrl || '').trim();
    if (!url) {
      return { ok: false, reason: 'No matched JSON URL is available for the custom creative fetch.' };
    }

    const editors = getCodeMirrorEditors(doc);
    for (const editor of editors) {
      if (replaceFetchUrlInEditor(editor, url)) {
        return { ok: true, updatedValue: url, node: 'CodeMirror' };
      }
    }

    const candidateNodes = doc.querySelectorAll
      ? Array.from(doc.querySelectorAll('textarea, input, [contenteditable="true"]'))
      : [];

    for (const node of candidateNodes) {
      if (replaceFetchUrlInPlainNode(node, url)) {
        return { ok: true, updatedValue: url, node: node.tagName || 'element' };
      }
    }

    return { ok: false, reason: 'No fetch(...) call was found in the custom creative code editor.' };
  }

  function findMacroTargetNodes(doc = global.document) {
    if (!doc || typeof doc.querySelectorAll !== 'function') {
      return [];
    }

    const selectors = [
      'button',
      '[role="button"]',
      'material-button',
      '[data-macro-name]',
      '[aria-label*="macro" i]',
      '[aria-label*="file" i]',
      '.macro-item',
      '.macro-row',
      '.macro-entry'
    ];

    const nodes = [];
    const seen = new Set();

    selectors.forEach((selector) => {
      const matches = doc.querySelectorAll(selector) || [];
      matches.forEach((node) => {
        if (!node || seen.has(node)) return;
        const text = [
          node.textContent || '',
          node.getAttribute?.('aria-label') || '',
          node.getAttribute?.('data-macro-name') || '',
          node.getAttribute?.('title') || '',
          node.id || ''
        ].join(' ');

        if (text || node.tagName === 'BUTTON') {
          seen.add(node);
          nodes.push(node);
        }
      });
    });

    return nodes;
  }

  function removeMacroByName(doc = global.document, desiredName = 'macro 1') {
    const name = normalizeMacroName(desiredName);
    const candidates = findMacroTargetNodes(doc);

    for (const node of candidates) {
      const label = [
        node.textContent || '',
        node.getAttribute?.('aria-label') || '',
        node.getAttribute?.('data-macro-name') || '',
        node.getAttribute?.('title') || '',
        node.id || ''
      ].join(' ').toLowerCase();

      if (label.includes(name)) {
        if (typeof node.click === 'function') {
          node.click();
          return { ok: true, name: desiredName, target: node };
        }
      }
    }

    return { ok: false, reason: `No macro entry named ${desiredName} was found.` };
  }

  function base64ToBytes(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }

  // Accepts a File/Blob directly, a raw JSON string, or a transferable
  // { base64, type } payload (used when the content had to cross a
  // JSON-only message boundary, e.g. the chrome.scripting.executeScript
  // fallback path).
  function buildMacroUploadFile(fileName = 'macro 1', fileContent = '') {
    const candidateName = String(fileName || 'macro 1').trim() || 'macro 1';

    if (fileContent instanceof File) {
      return new File([fileContent], candidateName, {
        type: fileContent.type || 'application/octet-stream',
        lastModified: fileContent.lastModified || Date.now()
      });
    }

    if (fileContent instanceof Blob) {
      return new File([fileContent], candidateName, {
        type: fileContent.type || 'application/octet-stream',
        lastModified: Date.now()
      });
    }

    if (fileContent && typeof fileContent === 'object' && typeof fileContent.base64 === 'string') {
      const bytes = base64ToBytes(fileContent.base64);
      return new File([bytes], candidateName, {
        type: fileContent.type || 'application/json',
        lastModified: Date.now()
      });
    }

    const source = typeof fileContent === 'string' ? fileContent : '';
    return new File([source || ''], candidateName, {
      type: 'application/json',
      lastModified: Date.now()
    });
  }

  function uploadMacroFile(doc = global.document, fileName = 'macro 1', fileContent = '') {
    if (!doc || typeof doc.querySelector !== 'function') {
      return { ok: false, reason: 'No document available for file upload.' };
    }

    const selectorFallbacks = [
      'input[type="file"]',
      'input[type="file"][accept]',
      '.browse-button input[type="file"]',
      'material-file-upload input[type="file"]',
      'custom-asset-uploader input[type="file"]'
    ];

    const input = selectorFallbacks
      .map((selector) => doc.querySelector(selector))
      .find(Boolean) || doc.querySelector('input[type="file"]');

    if (!input) {
      return { ok: false, reason: 'No file input was found on the GAM form.' };
    }

    try {
      const file = buildMacroUploadFile(fileName, fileContent);

      if (typeof DataTransfer !== 'undefined') {
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        input.files = dataTransfer.files;
      } else {
        input.files = [file];
      }

      const event = new Event('change', { bubbles: true, cancelable: true });
      input.dispatchEvent(event);

      return { ok: true, fileName: file.name, input };
    } catch (error) {
      return { ok: false, reason: error.message || 'Unable to set file on the GAM upload field.' };
    }
  }

  const api = {
    DEFAULT_SELECTOR_HINTS,
    getCandidateFields,
    resolveWriteTarget,
    isLikelyGAMPage,
    validateTargetState,
    normalizeMacroName,
    getCreativeTypeLabel,
    getCodeMirrorEditors,
    replaceFetchUrlInEditor,
    updateCustomCreativeFetchUrl,
    findMacroTargetNodes,
    removeMacroByName,
    buildMacroUploadFile,
    uploadMacroFile
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  }

  global.GAM_HELPERS = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
