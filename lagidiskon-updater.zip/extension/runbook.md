# Lagidiskon Updater — Operational Runbook

## Prerequisites
- Chrome, logged in to Google Ad Manager in the tab(s) you're working on.
- The extension loaded (see README.md).
- A source list URL (JSON array or Google Drive file) with `{ "name", "json_url" }` entries per site.

## 1. Configure the source list
1. Open the popup on any tab.
2. Confirm **Source list URL** points at the correct Drive/JSON file. It defaults to the shared internal list.
3. Optional: fill **Site override** if the GAM page title/text won't auto-match the right site (e.g. ambiguous creative names).

## 2. Single creative
1. Navigate to the GAM creative edit screen.
2. Open the popup. It auto-detects the **creative type** badge and resolves the **matched site / JSON URL**.
3. If the match looks wrong, adjust **Site override** and click **Refresh Match**.
4. Click **Apply Update on Active Tab**:
   - **Custom creative** → the matched URL replaces the URL inside the `fetch(...)` call in the CodeMirror code editor. Nothing else on the page is touched.
   - **Standard/macro template** → Macro 1 is removed and the matched JSON file is uploaded automatically as the replacement macro.
5. Watch the status line for the result (`Custom creative updated.` / `Macro upload complete.` / an error reason).

## 3. Batch — many open GAM tabs at once
1. Open one GAM creative tab per site you need to update.
2. Open the popup on any tab and click **Apply to All Open GAM Tabs**.
3. The extension re-resolves the matched source per tab (by tab title/content) and applies the same smart custom/macro logic to each.
4. Review the per-tab results list; anything marked `✗` includes the failure reason (e.g. "no fetch() found", "no matched source").
5. Fix the flagged tabs individually via the single-creative flow (Section 2) — there is no bulk retry; re-run **Apply to All Open GAM Tabs** once the underlying issue (wrong title match, page not fully loaded, etc.) is resolved.

## 4. Manual override
If you need to upload a specific local JSON file instead of the matched URL (e.g. a one-off hotfix), use **Or upload a file manually** at the bottom of the popup. This always runs the macro-upload flow (remove Macro 1 → upload the chosen file) and skips the custom-creative branch entirely.

## 5. Common failure reasons
| Status message | Likely cause |
| --- | --- |
| `No matching source was found for this tab.` | Site override doesn't match any entry in the source list, and the page title/content doesn't contain a recognizable site name. |
| `No fetch(...) call was found in the custom creative code editor.` | The custom creative's code doesn't contain a `fetch(...)` call, or the CodeMirror editor hasn't finished rendering yet — wait for the page to fully load and retry. |
| `Unable to remove Macro 1 from the GAM form.` | No macro row matching "macro 1" was found — check the macro's actual name on the page. |
| `Unable to download the matched JSON file (...)` | The matched `json_url` is unreachable or requires auth the browser session doesn't have. |
| `Could not reach the active GAM tab` | The content script hasn't loaded yet (freshly opened tab) — reload the GAM tab and retry. |

## 6. Validation before handoff
```bash
cd /Users/kly/Documents/GAM-JSON-UPDATER
node --test extension/gam-helpers.test.js extension/source-list.test.js extension/batch-helpers.test.js
node extension/validate-dry-run.js
```
